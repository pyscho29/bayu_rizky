<?php  
    error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
    session_start();
    include ("admin/inc/koneksi.php");
    include ("admin/inc/tanggal.php");    
?>  

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title><?php echo $judul ?></title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="admin/assets/<?php echo $logo ?>" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="scss/css2.css" rel="stylesheet"> 

    <!-- Font Awesome -->
    <link href="scss/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Topbar Start -->
    <div class="container-fluid">
        <div class="row bg-secondary py-2 px-xl-5">
            <div class="col-lg-6 d-none d-lg-block">
                <div class="d-inline-flex align-items-center">
                    <a class="text-dark" href=""><?php echo $judul ?></a>
                </div>
            </div>
            <div class="col-lg-6 text-center text-lg-right">
                <div class="d-inline-flex align-items-center"> 
                    <a class="text-dark px-2" href="">
                        (<small><?php echo $email ?></small>)
                    </a> |
                    <a class="text-dark px-2" href="">
                        (<small><?php echo $telp ?></small>)
                    </a> 
                </div>
            </div>
        </div> 
    </div>
    <!-- Topbar End -->   


    <!-- Products Start -->
    <div class="container-fluid pt-5"> <br>
        <div class="text-center mb-4">
            <h2 class="section-title px-5"><span class="px-2">Selamat Datang</span></h2> <br>
            <h4>Silahkan lengkapi form dibawah untuk melakukan pendafatran</h4>
        </div>
        <div class="row px-xl-5 pb-3"> 
            <div class="col-lg-4 pb-1"></div>
            <div class="col-lg-4 pb-1">
                <div class="card-body"> 
                    <form class="form-horizontal needs-validation" novalidate method="post">

                        <div class="mb-3">
                            <label class="form-label">Nama</label>
                            <input type="text" class="form-control" name="nama_pelanggan" autofocus required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Nomor Telepon</label>
                            <input type="text" class="form-control" name="nohp_pelanggan" required>
                        </div> 

                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="text" class="form-control" name="email_pelanggan" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Alamat</label>
                            <input type="text" class="form-control" name="alamat_pelanggan" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Username</label>
                            <input type="text" class="form-control" name="username_pelanggan" required>
                        </div> 

                        <div class="mb-3">
                            <label class="form-label">Password</label>
                            <input type="text" class="form-control" name="password_pelanggan" required>
                        </div>    <hr>

                        <div class="mt-3">
                            <button name="daftar" class="btn btn-primary w-100 waves-effect waves-light">D A F T A R</button> 
                        </div> 

                    </form>
                    <?php 
                    if (isset($_POST['daftar'])) 
                    {
                        $nama_pelanggan = $_POST['nama_pelanggan'];
                        $nohp_pelanggan = $_POST['nohp_pelanggan'];
                        $email_pelanggan = $_POST['email_pelanggan'];
                        $alamat_pelanggan = $_POST['alamat_pelanggan']; 
                        $username_pelanggan = $_POST['username_pelanggan'];
                        $password_pelanggan = $_POST['password_pelanggan'];

                       
                        $ambil = $con->query("SELECT * FROM pelanggan WHERE username_pelanggan='$username_pelanggan'");
                        $yangcocok = mysqli_num_rows($ambil);
                        if ($yangcocok==1) 
                        {
                            echo "<script>alert('Username sudah digunakan, silahkan gunakan yang lain.');</script>";
                            echo "<script>location='daftar.php';</script>";
                        }
                        else
                        {
                         
                            $con->query("INSERT INTO pelanggan
                            (nama_pelanggan,nohp_pelanggan,email_pelanggan,alamat_pelanggan,username_pelanggan,password_pelanggan,status_pelanggan) 
                            VALUES ('$nama_pelanggan','$nohp_pelanggan','$email_pelanggan','$alamat_pelanggan','$username_pelanggan','$password_pelanggan','Aktif') ");

                            echo "<script>alert('Pendaftaran berhasil, klik ok untuk login.');</script>";
                            echo "<script>location='index.php';</script>";
                        }
                    }
                    ?>
                </div>
            </div> 
            <div class="col-lg-4 pb-1"></div>
        </div>
    </div>
    <!-- Products End -->   


    <!-- Footer Start -->
    <?php include "footer.php" ?>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="scss/jquery-3.4.1.min.js"></script>
    <script src="scss/bootstrap.bundle.min.js"></script>
    <script src="scss/all.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script> 
</body>

</html>