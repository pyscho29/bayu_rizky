<?php
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
session_start();

// echo "<pre>";
// print_r($_SESSION['keranjang']);
// echo "</pre>";

include 'admin/inc/koneksi.php';

if (empty($_SESSION["keranjang"]) or !isset($_SESSION["keranjang"])) {
    echo "<script>alert('Keranjang masih kosong.');</script>";
    echo "<script>location='index.php';</script>";
    exit();
}

function f_pesan($length)
{
    $data = '1234567';
    $string = 'PSN';
    for ($i = 0; $i < $length; $i++) {
        $pos = rand(0, strlen($data) - 1);
        $string .= $data{
        $pos};
    }
    return $string;
}
$f_pesan = f_pesan(7);

$cek_minor = mysqli_query($con, "select * from pengaturan");
$data_minor = mysqli_fetch_array($cek_minor);
$minor = $data_minor['minimum_order'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title><?php echo $judul ?></title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="admin/assets/<?php echo $logo ?>" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="scss/css2.css" rel="stylesheet">

    <!-- Font Awesome -->
    <link href="scss/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Topbar Start -->
    <div class="container-fluid">
        <div class="row bg-secondary py-2 px-xl-5">
            <div class="col-lg-6 d-none d-lg-block">
                <div class="d-inline-flex align-items-center">
                    <a class="text-dark" href=""><?php echo $judul ?></a>
                </div>
            </div>
            <div class="col-lg-6 text-center text-lg-right">
                <div class="d-inline-flex align-items-center">
                    <a class="text-dark px-2" href="">
                        (<small><?php echo $email ?></small>)
                    </a> |
                    <a class="text-dark px-2" href="">
                        (<small><?php echo $telp ?></small>)
                    </a>
                </div>
            </div>
        </div>
        <div class="row align-items-center py-3 px-xl-5">
            <div class="col-lg-3 d-none d-lg-block">
                <a href="" class="text-decoration-none">
                    <h1 class="m-0 display-5 font-weight-semi-bold"><span class="text-warning font-weight-bold border px-3 mr-1">E</span><?php echo $singkatan ?></h1>
                </a>
            </div>
            <div class="col-lg-6 col-6 text-left">
                <form action="cari.php" method="GET">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Cari Menu Disini..." name="key">
                        <div class="input-group-append">
                            <input type="submit" name="open" value="Cari Menu" class="btn btn-secondary btn-sm">
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-lg-3 col-6 text-right">
                <?php if (isset($_SESSION["pelanggan"])) : ?>
                    <a href="logout.php" class="btn border">
                        <span class="badge">Logout</span>
                    </a>
                <?php else : ?>
                    <a href="login.php" class="btn border">
                        <span class="badge">Login</span>
                    </a>
                    <a href="" class="btn border">
                        <span class="badge">Daftar</span>
                    </a>
                <?php endif ?>
            </div>
        </div>
    </div>
    <!-- Topbar End -->


    <!-- Navbar Start -->
    <div class="container-fluid">
        <div class="row border-top px-xl-5">
            <?php include "kat.php" ?>
            <div class="col-lg-9">
                <?php include "menu.php" ?>
            </div>
        </div>
    </div>
    <!-- Navbar End -->

    <div class="container-fluid bg-secondary mb-5">
        <div class="d-flex flex-column align-items-center justify-content-center" style="min-height: 300px">
            <h1 class="font-weight-semi-bold text-uppercase mb-3">Keranjang</h1>
            <div class="d-inline-flex">
                <p class="m-0"><a href="index.php">Home</a></p>
                <p class="m-0 px-2">-</p>
                <p class="m-0">Keranjang</p>
            </div>
        </div>
    </div>


    <!-- Shop Detail Start -->
    <div class="container-fluid py-5">
        <div class="row px-xl-5">
            <div class="col-lg-8 table-responsive mb-5">
                <table class="table table-bordered text-center mb-0">
                    <thead class="bg-secondary text-dark">
                        <tr>
                            <th>#</th>
                            <th>Menu</th>
                            <th>Harga</th>
                            <th>Jumlah</th>
                            <th>Sub Total</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="align-middle">
                        <?php $nomor = 1; $lanjut='ya';?>
                        <?php foreach ($_SESSION["keranjang"] as $id_menu => $jumlah) : ?>
                            <?php
                            $ambil = $con->query("SELECT * FROM menu WHERE id_menu='$id_menu'");
                            $pecah = $ambil->fetch_assoc();
                            $sub_total = $pecah["harga"] * $jumlah;
                            $sub_total12 = $sub_total12 + $sub_total;
                            ?>
                            <tr>
                                <td>
                                    <img class="w-100 h-100" src="admin/assets/foto/<?php echo $pecah['foto'] ?>" style="max-width: 50px;" alt="Image">
                                </td>
                                <td style="vertical-align: middle;"><?php echo $pecah["menu"]; ?></td>
                                <td style="vertical-align: middle;"><?php echo number_format($pecah['harga'], 0, ',', '.') ?></td>
                                <td style="vertical-align: middle;"><?php echo $jumlah; ?> /Porsi<br>
                                    <span id="minor" style="display:<?php if($jumlah>=$minor){echo'none';}else{echo'block';}?>" ><font color="red" size="2px">Minimum order : <?php echo $minor; ?> porsi</font></span>
                                </td>
                                <td style="vertical-align: middle;"><?php echo number_format($sub_total, 0, ',', '.') ?></td>
                                <td style="vertical-align: middle;">
                                    <a href="hapus.php?id_menu=<?php echo $id_menu; ?>" class="btn btn-danger btn-xs">Hapus</a>
                                </td>
                            </tr>
                            <?php $nomor++; ?>
                        <?php $total_bayar = $sub_total + $total_bayar;
                        

                        if($jumlah < $minor){$lanjut='tidak';}

                        endforeach ?>
                        
                    </tbody>
                </table>
            </div>
            <div class="col-lg-4">
                <div class="card border-secondary mb-5">
                    <div class="card-header bg-secondary border-0">
                        <h4 class="font-weight-semi-bold m-0">Cart Summary</h4>
                    </div>
                    <div class="card-footer border-secondary bg-transparent">
                        <div class="d-flex justify-content-between mt-2">
                            <input type="hidden" id="valid" value="<?php echo $lanjut;?>">
                            <h5 class="font-weight-bold">Total</h5>
                            <h5 class="font-weight-bold"><?php echo number_format($total_bayar, 0, ',', '.') ?></h5>
                        </div>
                        <a href="#" onclick="checkout()" class="btn btn-block btn-success my-3 py-3">Checkout</a>
                        <a class="btn btn-block btn-warning my-3 py-3" href="index.php">Beli Lagi</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="row px-xl-5">
            <div class="col"></div>
        </div>
    </div>
    <!-- Shop Detail End -->


    <!-- Footer Start -->
    <?php include "footer.php" ?>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="scss/jquery-3.4.1.min.js"></script>
    <script src="scss/bootstrap.bundle.min.js"></script>
    <script src="scss/all.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
    <script>
        function checkout() {            
            var valid = document.getElementById('valid').value;
            if(valid=='ya'){location='checkout.php';}
            else{alert('Jumlah minimum order belum terpenuhi.');}
        }
    </script>
</body>

</html>