<?php  
    error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
    session_start();
    include ("admin/inc/koneksi.php");
    include ("admin/inc/tanggal.php");    
?>  

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title><?php echo $judul ?></title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="admin/assets/<?php echo $logo ?>" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="scss/css2.css" rel="stylesheet"> 

    <!-- Font Awesome -->
    <link href="scss/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Topbar Start -->
    <div class="container-fluid">
        <div class="row bg-secondary py-2 px-xl-5">
            <div class="col-lg-6 d-none d-lg-block">
                <div class="d-inline-flex align-items-center">
                    <a class="text-dark" href=""><?php echo $judul ?></a>
                </div>
            </div>
            <div class="col-lg-6 text-center text-lg-right">
                <div class="d-inline-flex align-items-center"> 
                    <a class="text-dark px-2" href="">
                        (<small><?php echo $email ?></small>)
                    </a> |
                    <a class="text-dark px-2" href="">
                        (<small><?php echo $telp ?></small>)
                    </a> 
                </div>
            </div>
        </div>
        <div class="row align-items-center py-3 px-xl-5">
            <div class="col-lg-3 d-none d-lg-block">
                <a href="" class="text-decoration-none">
                    <h1 class="m-0 display-5 font-weight-semi-bold"><span class="text-warning font-weight-bold border px-3 mr-1">E</span><?php echo $singkatan ?></h1>
                </a>
            </div>
            <div class="col-lg-6 col-6 text-left">
                <form action="cari.php" method="GET">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Cari Menu Disini..." name="key">
                        <div class="input-group-append">
                            <input type="submit" name="open" value="Cari Menu" class="btn btn-secondary btn-sm">   
                        </div>
                    </div>
                </form> 
            </div>
            <div class="col-lg-3 col-6 text-right">
                <?php if (isset($_SESSION["pelanggan"])): ?>
                <a href="logout.php" class="btn border"> 
                    <span class="badge">Logout</span>
                </a> 
                <?php else: ?>
                <a href="login.php" class="btn border"> 
                    <span class="badge">Login</span>
                </a>
                <a href="" class="btn border"> 
                    <span class="badge">Daftar</span>
                </a> 
                <?php endif ?>
            </div>
        </div>
    </div>
    <!-- Topbar End -->


    <!-- Navbar Start -->
    <div class="container-fluid mb-5">
        <div class="row border-top px-xl-5">
            <?php include "kat.php" ?>
            <div class="col-lg-9">
                <?php include "menu.php" ?>
                <div id="header-carousel" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner">
                        <div class="carousel-item active" style="height: 410px;">
                            <img class="img-fluid" src="img/bg1.jpg" alt="Image">
                            <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
                                <div class="p-3" style="max-width: 700px;">
                                    <h4 class="text-light text-uppercase font-weight-medium mb-3"> <?php echo $judul ?> </h4>
                                    <h3 class="display-4 text-white font-weight-semi-bold mb-4">Higienis dan Enak</h3>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item" style="height: 410px;">
                            <img class="img-fluid" src="img/bg2.jpg" alt="Image">
                            <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
                                <div class="p-3" style="max-width: 700px;">
                                    <h4 class="text-light text-uppercase font-weight-medium mb-3"> <?php echo $judul ?> </h4>
                                    <h3 class="display-4 text-white font-weight-semi-bold mb-4">Harga mahasiswa</h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    <a class="carousel-control-prev" href="#header-carousel" data-slide="prev">
                        <div class="btn btn-dark" style="width: 45px; height: 45px;">
                            <span class="carousel-control-prev-icon mb-n2"></span>
                        </div>
                    </a>
                    <a class="carousel-control-next" href="#header-carousel" data-slide="next">
                        <div class="btn btn-dark" style="width: 45px; height: 45px;">
                            <span class="carousel-control-next-icon mb-n2"></span>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <!-- Navbar End -->      


    <!-- Products Start -->
    <div class="container-fluid pt-5">
        <div class="text-center mb-4">
            <h2 class="section-title px-5"><span class="px-2">Menu Catering</span></h2>
        </div>
        <div class="row px-xl-5 pb-3">
            <?php
            global $con;
            $key = $_GET['key'];
            $key = explode(" ", $key);
            sort($key);
            $stradd = '';
            foreach ($key as $val) 
            {
                if ($stradd !='') 
                {
                    $stradd .= " OR menu LIKE '%{$val}%' OR kategori LIKE '%{$val}%' ";
                }else{
                    $stradd .= " AND menu LIKE '%{$val}%' OR kategori LIKE '%{$val}%' ";
                }
            }

            $sql = mysqli_query($con, "SELECT * FROm menu NATURAL JOIN kategori WHERE status_menu='Aktif' $stradd ORDER BY id_menu DESC LIMIT 0,10 ");
            while ($b = mysqli_fetch_array($sql)) 
            {
                extract($b);
                echo '
                        <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
                            <div class="card product-item border-0 mb-4">
                                <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                                    <img class="img-fluid w-100" src="admin/assets/foto/'.$foto.'" alt="">
                                </div>
                                <div class="card-body border-left border-right text-center p-0 pt-4 pb-3">
                                    <h6 class="text-truncate mb-3">'.$menu.'</h6>
                                    <div class="d-flex justify-content-center">
                                        <h6>'.$harga.'</h6></h6>
                                    </div>
                                </div>
                                <div class="card-footer d-flex justify-content-between bg-light border">
                                    <a href="detail.php?id_menu='.$id_menu.'" class="btn btn-sm text-dark p-0"><i class="fas fa-eye text-primary mr-1"></i> Detail</a>
                                    <a href="beli.php?id_menu='.$id_menu.'" class="btn btn-sm text-dark p-0"><i class="fas fa-shopping-cart text-primary mr-1"></i> Sewa</a>
                                </div>
                            </div>
                        </div> 
                     '
                ;
            }

            ?>  
        </div>
    </div>
    <!-- Products End -->   


    <!-- Footer Start -->
    <?php include "footer.php" ?>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="scss/jquery-3.4.1.min.js"></script>
    <script src="scss/bootstrap.bundle.min.js"></script>
    <script src="scss/all.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script> 
</body>

</html>