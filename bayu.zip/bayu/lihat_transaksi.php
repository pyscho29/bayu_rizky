<?php 
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING)); 
session_start();

// echo "<pre>";
// print_r($_SESSION['keranjang']);
// echo "</pre>";

include 'admin/inc/koneksi.php';

if (!isset($_SESSION['pelanggan'])) 
{
    echo "<script>alert('Silahkan login !');</script>";
    echo "<script>location='login.php';</script>";
    exit();
} 
?> 

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title><?php echo $judul ?></title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="admin/assets/<?php echo $logo ?>" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="scss/css2.css" rel="stylesheet"> 

    <!-- Font Awesome -->
    <link href="scss/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Topbar Start -->
    <div class="container-fluid">
        <div class="row bg-secondary py-2 px-xl-5">
            <div class="col-lg-6 d-none d-lg-block">
                <div class="d-inline-flex align-items-center">
                    <a class="text-dark" href=""><?php echo $judul ?></a>
                </div>
            </div>
            <div class="col-lg-6 text-center text-lg-right">
                <div class="d-inline-flex align-items-center"> 
                    <a class="text-dark px-2" href="">
                        (<small><?php echo $email ?></small>)
                    </a> |
                    <a class="text-dark px-2" href="">
                        (<small><?php echo $telp ?></small>)
                    </a> 
                </div>
            </div>
        </div>
        <div class="row align-items-center py-3 px-xl-5">
            <div class="col-lg-3 d-none d-lg-block">
                <a href="" class="text-decoration-none">
                    <h1 class="m-0 display-5 font-weight-semi-bold"><span class="text-warning font-weight-bold border px-3 mr-1">E</span><?php echo $singkatan ?></h1>
                </a>
            </div>
            <div class="col-lg-6 col-6 text-left">
                <form action="cari.php" method="GET">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Cari Menu Disini..." name="key">
                        <div class="input-group-append">
                            <input type="submit" name="open" value="Cari Menu" class="btn btn-secondary btn-sm">   
                        </div>
                    </div>
                </form> 
            </div>
            <div class="col-lg-3 col-6 text-right">
                <?php if (isset($_SESSION["pelanggan"])): ?>
                <a href="logout.php" class="btn border"> 
                    <span class="badge">Logout</span>
                </a> 
                <?php else: ?>
                <a href="login.php" class="btn border"> 
                    <span class="badge">Login</span>
                </a>
                <a href="" class="btn border"> 
                    <span class="badge">Daftar</span>
                </a> 
                <?php endif ?>
            </div>
        </div>
    </div>
    <!-- Topbar End -->


    <!-- Navbar Start -->
     <div class="container-fluid">
        <div class="row border-top px-xl-5">
            <?php include "kat.php" ?>
            <div class="col-lg-9">
                <?php include "menu.php" ?>
            </div>
        </div>
    </div>
    <!-- Navbar End -->   

    <div class="container-fluid bg-secondary mb-5">
        <div class="d-flex flex-column align-items-center justify-content-center" style="min-height: 300px">
            <h1 class="font-weight-semi-bold text-uppercase mb-3">Checkout</h1>
            <div class="d-inline-flex">
                <p class="m-0"><a href="index.php">Home</a></p>
                <p class="m-0 px-2">-</p>
                <p class="m-0">Checkout</p>
            </div>
        </div>
    </div>


    <!-- Shop Detail Start -->
    <!-- Checkout Start -->
    <div class="container-fluid pt-5">
        <div class="row px-xl-5"> 
            <div class="col-lg-5">
                <div class="card border-secondary mb-5">
                    <div class="card-header bg-secondary border-0">
                        <h4 class="font-weight-semi-bold m-0">List Order Total</h4>
                    </div>
                    <div class="card-body"> 
                        <div class="d-flex justify-content-between">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Menu</th>
                                        <th>Harga</th>
                                        <th>Jumlah</th>
                                        <th class="text-right">S.Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $totalbelanja = 0; ?>
                                    <?php foreach ($_SESSION["keranjang"] as $id_menu => $jumlah): ?> 
                                    <?php 
                                    $ambil = $con->query("SELECT * FROM menu WHERE id_menu='$id_menu'");
                                    $pecah = $ambil->fetch_assoc();
                                    $sub_total = $pecah["harga"]*$jumlah; 
                                    ?>
                                    <tr>
                                        <td><?php echo $pecah["menu"]; ?></td>
                                        <td><?php echo number_format($pecah['harga'], 0, ',','.') ?></td>
                                        <td><?php echo $jumlah; ?> /Porsi</td>
                                        <td class="text-right"><?php echo number_format($sub_total, 0, ',','.'); ?>,-</td>
                                    </tr>
                                </tbody>
                                <?php $totalbelanja+=$sub_total; ?>
                                <?php endforeach ?>
                                <hr class="mt-0"> 
                                <tfoot>
                                    <th colspan="3" class="bg-secondary text-center">Total Bayar</th>
                                    <th class="text-right">Rp. <?php echo number_format($totalbelanja, 0, ',','.'); ?>,-</th>
                                </tfoot>
                            </table> 
                        </div>  
                    </div>                     
                </div>
            </div>
            <div class="col-lg-7">
                <div class="mb-4">
                    <h4 class="font-weight-semi-bold mb-4">Billing Address</h4>
                    <form action="#" method="POST" class="billing-form">
                        <div class="row">
                            <div class="col-md-6 form-group">
                                <label>Nama</label>
                                <input class="form-control" type="text" value="<?php echo $_SESSION['pelanggan']['nama_pelanggan'] ?>" readonly required>
                            </div>
                            <div class="col-md-6 form-group">
                                <label>No. Telepon</label>
                                <input class="form-control" type="text" value="<?php echo $_SESSION['pelanggan']['nohp_pelanggan'] ?>" readonly required>
                            </div>
                            <div class="col-md-6 form-group">
                                <label>Email</label>
                                <input class="form-control" type="text" value="<?php echo $_SESSION['pelanggan']['email_pelanggan'] ?>" readonly required>
                            </div>
                            <div class="col-md-6 form-group">
                                <label>Alamat</label>
                                <input class="form-control" type="text" value="<?php echo $_SESSION['pelanggan']['alamat_pelanggan'] ?>" readonly required>
                            </div>
                            <div class="col-md-12 form-group">
                                <label>Dikirim Ke</label>
                                <textarea class="form-control" name="alamat_pesan" cols="10" rows="3" required placeholder="Mohon masukan secara lengkap dan detail agar mudah ditemukan"></textarea>
                            </div> 
                            <div class="col-md-12 form-group">
                                <button class="btn btn-primary" name="checkout">Checkout</button>
                            </div> 
                        </div>
                    </form>
                    <?php 
                    if (isset($_POST['checkout']))
                    {
                        $id_pelanggan = $_SESSION['pelanggan']['id_pelanggan']; 
                        $tgl_pesan = date("Y-m-d");
                        $alamat_pesan = $_POST['alamat_pesan']; 

                        $total_pesan = $totalbelanja + $ongkir; 

                        $con->query("INSERT INTO pesan (id_pelanggan,tgl_pesan,total_pesan,alamat_pesan,sts_pesan) VALUES ('$id_pelanggan','$tgl_pesan','$total_pesan','$alamat_pesan','Pending')");

                        $id_pembelian_barusan = $con->insert_id;

                        foreach ($_SESSION['keranjang'] as $id_menu => $jumlah) 
                        {
                            $ambil = $con->query("SELECT * FROM menu WHERE id_menu='$id_menu'");
                            $perproduk = $ambil->fetch_assoc();

                            $nama_menu = $perproduk['menu'];
                            $hmenu = $perproduk['harga']; 
                            $subharga = $perproduk['harga']*$jumlah;

                            $con->query("INSERT INTO pesan_detail (id_pesan,id_menu,nama_menu,hmenu,subharga,jumlah) 
                            VALUES ('$id_pembelian_barusan','$id_menu','$nama_menu','$hmenu','$subharga','$jumlah')");
                        }

                        // kosongkan isi keranjang
                        unset($_SESSION['keranjang']);

                        // ketika selesai akan diarahkan ke halaman nota pembelian
                        echo "<script>alert('Pembelian berhasil');</script>";
                        echo "<script>location='riwayat.php';</script>";
                    }
                    ?> 
                </div>
            </div>
        </div>
    </div>
    <!-- Checkout End -->
    <!-- Shop Detail End -->  


    <!-- Footer Start -->
    <?php include "footer.php" ?>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="scss/jquery-3.4.1.min.js"></script>
    <script src="scss/bootstrap.bundle.min.js"></script>
    <script src="scss/all.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script> 
</body>

</html>