<?php 
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING)); 
session_start();

// echo "<pre>";
// print_r($_SESSION['keranjang']);
// echo "</pre>";

// include "admin/inc/tanggal.php"; 
include 'admin/inc/koneksi.php'; 

if (!isset($_SESSION['pelanggan'])) 
{
    echo "<script>alert('Silahkan login !');</script>";
    echo "<script>location='login.php';</script>";
    exit();
} 

function f_pesan($length)
{
    $data = '1234567';
    $string = 'PSN';
    for ($i=0; $i < $length; $i++)
    {
        $pos = rand(0, strlen($data)-1);
        $string .= $data{$pos}; 
    }
    return $string;
}
$f_pesan= f_pesan(7);

?> 

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title><?php echo $judul ?></title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="admin/assets/<?php echo $logo ?>" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="scss/css2.css" rel="stylesheet"> 

    <!-- Font Awesome -->
    <link href="scss/all.min.css" rel="stylesheet">
    <link href="scss/bootstrap.css" rel="stylesheet">
    <link href="scss/dataTables.bootstrap4.min.css.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Topbar Start -->
    <div class="container-fluid">
        <div class="row bg-secondary py-2 px-xl-5">
            <div class="col-lg-6 d-none d-lg-block">
                <div class="d-inline-flex align-items-center">
                    <a class="text-dark" href=""><?php echo $judul ?></a>
                </div>
            </div>
            <div class="col-lg-6 text-center text-lg-right">
                <div class="d-inline-flex align-items-center"> 
                    <a class="text-dark px-2" href="">
                        (<small><?php echo $email ?></small>)
                    </a> |
                    <a class="text-dark px-2" href="">
                        (<small><?php echo $telp ?></small>)
                    </a> 
                </div>
            </div>
        </div>
        <div class="row align-items-center py-3 px-xl-5">
            <div class="col-lg-3 d-none d-lg-block">
                <a href="" class="text-decoration-none">
                    <h1 class="m-0 display-5 font-weight-semi-bold"><span class="text-warning font-weight-bold border px-3 mr-1">E</span><?php echo $singkatan ?></h1>
                </a>
            </div>
            <div class="col-lg-6 col-6 text-left">
                <form action="cari.php" method="GET">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Cari Menu Disini..." name="key">
                        <div class="input-group-append">
                            <input type="submit" name="open" value="Cari Menu" class="btn btn-secondary btn-sm">   
                        </div>
                    </div>
                </form> 
            </div>
            <div class="col-lg-3 col-6 text-right">
                <?php if (isset($_SESSION["pelanggan"])): ?>
                <a href="logout.php" class="btn border"> 
                    <span class="badge">Logout</span>
                </a> 
                <?php else: ?>
                <a href="login.php" class="btn border"> 
                    <span class="badge">Login</span>
                </a>
                <a href="" class="btn border"> 
                    <span class="badge">Daftar</span>
                </a> 
                <?php endif ?>
            </div>
        </div>
    </div>
    <!-- Topbar End -->


    <!-- Navbar Start -->
     <div class="container-fluid">
        <div class="row border-top px-xl-5">
            <?php include "kat.php" ?>
            <div class="col-lg-9">
                <?php include "menu.php" ?>
            </div>
        </div>
    </div>
    <!-- Navbar End -->   

    <div class="container-fluid bg-secondary mb-5">
        <div class="d-flex flex-column align-items-center justify-content-center" style="min-height: 300px">
            <h1 class="font-weight-semi-bold text-uppercase mb-3">Riwayat Transaksi</h1>
            <div class="d-inline-flex">
                <p class="m-0"><a href="index.php">Home</a></p>
                <p class="m-0 px-2">-</p>
                <p class="m-0">Riwayat Transaksi</p>
            </div>
        </div>
    </div>


    <!-- Shop Detail Start -->
    <div class="container-fluid py-5">
        <div class="row px-xl-5">
            <div class="col-lg-12 table-responsive mb-5">
                <table  class="table table-striped table-bordered" style="width:100%">
                    <thead class="bg-secondary text-dark">
                        <tr>
                            <th>#</th>
                            <th>NPesan</th>
                            <th>Tanggal</th>
                            <th class="text-right">Total</th>
                            <th class="text-center">Status</th>
                            <th class="text-center">#</th>
                        </tr>
                    </thead>
                    <tbody class="align-middle">
                        <?php
                        $nomor=1;
                        $id_pelanggan = $_SESSION['pelanggan']['id_pelanggan'];
                        $ambil = $con->query("SELECT * FROM pesan WHERE id_pelanggan='$id_pelanggan'");
                        while ($pecah = $ambil->fetch_assoc()) { 
                        ?>
                        <tr>
                            <td><?php echo $nomor; ?></td>
                            <td><?php echo $pecah['id_pesan'] ?></td> 
                            <td><?php echo $pecah['tgl_pesan'] ?></td> 
                            <td class="text-right">Rp. <?php echo number_format($pecah['total_pesan']) ?></td>
                            <td class="text-center"><?php echo $pecah['sts_pesan'] ?></td>
                            <td class="text-center">
                                <a href="nota.php?id_pesan=<?php echo $pecah['id_pesan'] ?>" target="blank" data-toggle="tooltip" data-placement="bottom" title="Nota" class="btn btn-info"><i class="fa fa-file"></i></a>
                                <a href="bayar.php?id_pesan=<?php echo $pecah['id_pesan'] ?>" data-toggle="tooltip" data-placement="bottom" title="Bayar" class="btn btn-success"><i class="fa fa-calculator"></i></a>
                            </td>
                        </tr>
                        <?php $nomor++; ?>
                        <?php } ?>
                    </tbody>
                </table>
            </div> 
        </div>
        <div class="row px-xl-5">
            <div class="col"></div>
        </div>
    </div>
    <!-- Shop Detail End -->  


    <!-- Footer Start -->
    <?php include "footer.php" ?>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="scss/jquery-3.4.1.min.js"></script>
    <script src="scss/bootstrap.bundle.min.js"></script>
    <script src="scss/all.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script> 
    <script src="scss/dataTables.bootstrap4.min.js"></script> 
    <script src="scss/jquery.dataTables.min.js"></script> 

    <script>
        $(document).ready(function () {
            $('#example').DataTable();
        });

        $(function () {
          $('[data-toggle="tooltip"]').tooltip()
        })
    </script>
</body>

</html>