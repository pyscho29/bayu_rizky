<?php 
session_start();
//mendapatkan id_menu
$id_menu = $_GET['id_menu'];

// jika produk sudah ada dikeranjang, maka produk akan di tambah 1
if (isset($_SESSION['keranjang'][$id_menu])) 
{
	$_SESSION['keranjang'][$id_menu] +=1;
}
// apabila stok belum ada dikeranjang, produk itu dianggap 1 atau di hitung 1
else
{
	$_SESSION['keranjang'][$id_menu] = 1;
}

// echo "<pre>";
// print_r($_SESSION);
// echo "</pre>";

// di larikan ke halaman keranjang
echo "<script>alert('Menu telah masuk ke keranjang');</script>";
echo "<script>location='keranjang.php';</script>";
?>