<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Riwayat Transaksi</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="index.php">Beranda</a></li>
                    <li class="breadcrumb-item">Riwayat Transaksi</li>
                    <li class="breadcrumb-item active">Lihat Transaksi</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title --> 

<div class="row"> 
    <?php $ambil = $con->query("SELECT * FROM pesan NATURAL JOIN pelanggan WHERE id_pelanggan ='$_GET[id_pelanggan]'"); ?>
    <?php while ($riwayat = $ambil->fetch_assoc()) { 
        $tgl = tgl_indo($riwayat['tgl_pesan']);  
        $bilang = terbilang($riwayat['total_pesan']); 
        $total1 = $riwayat['total_pesan']; 
        $total2 = $total1 + $total2; 
        $bilangtotal = terbilang($total2); 
        $pelanggan = $riwayat['nama_pelanggan']; 
    ?>
    <div class="col-md-6">
        <div class="card border card-border-primary">
            <div class="card-header">
                <span class="float-end badge bg-warning text-dark border-1 align-middle fs-10"><?php echo $riwayat['sts_pesan'] ?></span>
                <h6 class="card-title mb-0">Transaksi : <?php echo $tgl ?></h6>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <span class="badge bg-soft-success text-dark border-1 align-middle fs-10">Nomor Nota : <?php echo $riwayat['id_pesan'] ?></span>
                    </div>
                    <div class="col-md-6">
                        <span class="float-end badge bg-soft-success text-dark border-1 align-middle fs-10">Tanggal : <?php echo $tgl ?></span>
                    </div> <p></p>
                    <div class="col-md-12">
                        <div class="table-responsive">
                            <table class="table table-bordered border-dark align-middle table-nowrap mb-0 table-sm">
                                <thead class="thead-light">
                                    <tr> 
                                        <th><b>Menu</b></th>  
                                        <th style="text-align: right;"><b>Harga</b></th>
                                        <th class="text-center"><b>Jumlah</b></th> 
                                        <th style="text-align: right;"><b>S.Total</b></th>  
                                    </tr>
                                </thead>
                                <tbody>  
                                    <tr>
                                        <td class="text-left">
                                            <?php 
                                            $no= 1;
                                                $sql_barang = mysqli_query($con, "SELECT * FROM pesan_detail WHERE id_pesan = '$riwayat[id_pesan]'");
                                                    while ($data_barang = mysqli_fetch_array($sql_barang)){
                                                    echo $no++. ". "; echo $data_barang['nama_menu']."<br>";
                                                } 
                                            ?>
                                        </td>  
                                        <td align="right">
                                            <?php 
                                            $no= 1;
                                                $sql_barang = mysqli_query($con, "SELECT * FROM pesan_detail WHERE id_pesan = '$riwayat[id_pesan]'");
                                                    while ($data_barang = mysqli_fetch_array($sql_barang)){
                                                    echo number_format($data_barang['hmenu'], 0, ',','.')." <br>";
                                                } 
                                            ?>
                                        </td>
                                        <td align="center">
                                            <?php 
                                            $no= 1;
                                                $sql_barang = mysqli_query($con, "SELECT * FROM pesan_detail WHERE id_pesan = '$riwayat[id_pesan]'");
                                                    while ($data_barang = mysqli_fetch_array($sql_barang)){
                                                    echo $data_barang['jumlah']." /Porsi <br>";
                                                } 
                                            ?>
                                        </td> 
                                        <td align="right">
                                            <?php 
                                            $no= 1;
                                                $sql_barang = mysqli_query($con, "SELECT * FROM pesan_detail WHERE id_pesan = '$riwayat[id_pesan]'");
                                                    while ($data_barang = mysqli_fetch_array($sql_barang)){
                                                    echo number_format($data_barang['subharga'], 0, ',','.')." <br>";
                                                } 
                                            ?>
                                        </td>
                                    </tr>  
                                </tbody>
                                <tr>
                                    <th colspan="3" style="text-align: right;"><b>Total Bayar</b></th>
                                    <td style="text-align: right;"><b><?php echo number_format($riwayat['total_pesan'], 0, ',','.') ?></b></td>
                                </tr> 
                                <!-- <tr>
                                    <th colspan="3" style="text-align: right;"><b>TERBILANG</b></th>
                                    <td style="text-align: right;"></td>
                                </tr>  -->
                            </table>
                        </div>
                        
                    </div>
                </div> 
            </div>
        </div>
    </div><!-- end col -->
    <?php } ?> 
</div>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Total Transaksi Pelanggan - <b><?php echo $pelanggan ?></b></h3> 
            </div>
            <div class="card-body">
                <table class="table">
                    <tr>
                        <td>Total Transaksi</td>
                        <td><?php echo number_format($total2, 0, ',','.') ?>,-</td>
                    </tr>
                    <tr>
                        <td>Terbilang</td>
                        <td><?php echo $bilangtotal ?> Rupiah</td>
                    </tr>
                </table> 
            </div>
        </div>
    </div>
</div>