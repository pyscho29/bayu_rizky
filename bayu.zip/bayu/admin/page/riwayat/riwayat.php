<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Riwayat Pesanan</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="index.php">Beranda</a></li>
                    <li class="breadcrumb-item active">Riwayat Pesanan</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Data Riwayat Pesanan Pelanggan</h5>
            </div>
            <div class="card-body"> 

                <table id="fixed-header" class="table table-bordered dt-responsive nowrap table-striped align-middle" style="width:100%">
                    <thead>
                        <tr>
                            <th class="text-center" style="width: 10px;">No.</th>
                            <th>Nama</th>    
                            <th class="text-center" style="width: 10px;">#</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $nomor=1; ?>
                        <?php $ambil=$con->query("SELECT * FROM  pelanggan ORDER BY id_pelanggan DESC"); ?>
                        <?php while ($pecah = $ambil->fetch_assoc()) { 
                            $tgl = tgl_indo($pecah['tgl_pesan']); ?>
                        <tr> 
                            <td><?php echo $nomor; ?></td>
                            <td><?php echo $pecah['nama_pelanggan']; ?></td>   
                            <td>
                                <a href="?page=riwayat&aksi=lihat&id_pelanggan=<?php echo $pecah['id_pelanggan'] ?>" title="Lihat Transaksi    " class="btn btn-soft-danger btn-sm"> <i class="ri-file-list-3-line"></i></a> 
                            </td> 
                        </tr>
                        <?php $nomor++; ?>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div> 
</div>