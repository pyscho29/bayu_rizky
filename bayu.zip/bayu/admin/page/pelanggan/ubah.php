<?php 
$id_pelanggan = $_GET['id_pelanggan'];
$ambil = $con->query("SELECT * FROM pelanggan WHERE id_pelanggan ='$_GET[id_pelanggan]'");
$pecah = $ambil->fetch_assoc(); 
$status_pelanggan = $pecah['status_pelanggan'];
?>

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Pelanggan</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="index.php">Beranda</a></li>
                    <li class="breadcrumb-item">Data Master</li>
                    <li class="breadcrumb-item">Pelanggan</li>
                    <li class="breadcrumb-item active">Ubah Data</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Ubah Data</h5>
            </div>
            <div class="card-body">
                <form class="needs-validation" novalidate method="POST" enctype="multipart/form-data"> 
                    <div class="row">
                        <div class="col-md-6">
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label">Nama</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="nama_pelanggan" value="<?php echo $pecah['nama_pelanggan'] ?>" autofocus required> 
                                </div>
                            </div> 
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label">Nomor Telepon</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="nohp_pelanggan" value="<?php echo $pecah['nohp_pelanggan'] ?>" required> 
                                </div>
                            </div> 
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label">Email</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="email_pelanggan" value="<?php echo $pecah['email_pelanggan'] ?>" required> 
                                </div>
                            </div> 
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label">Alamat</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="alamat_pelanggan" value="<?php echo $pecah['alamat_pelanggan'] ?>" required> 
                                </div>
                            </div>    
                        </div>
                        <div class="col-md-6">
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label">Username</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="username_pelanggan" value="<?php echo $pecah['username_pelanggan'] ?>" required> 
                                </div>
                            </div> 
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label">Password</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="password_pelanggan" value="<?php echo $pecah['password_pelanggan'] ?>" required> 
                                </div>
                            </div> 
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label">Status</label>
                                <div class="col-sm-9">
                                    <select class="js-example-basic-single" name="status_pelanggan">
                                        <option>Pilih Status</option>  
                                        <option value="Aktif" <?php if ($status_pelanggan=='Aktif') { echo "selected"; } ?>>Aktif</option>
                                        <option value="Non Aktif" <?php if ($status_pelanggan=='Non Aktif') { echo "selected"; } ?>>Non Aktif</option>
                                    </select> 
                                </div>
                            </div> 
                            <div class="row">
                                <label class="col-sm-3 col-form-label">&nbsp;</label>
                                <div class="col-sm-9">
                                    <input type="submit" name="simpan" value="Simpan" class="btn btn-sm btn-primary"> 
                                    <a href="?page=pelanggan" class="btn btn-danger btn-sm"> Kembali</a>
                                </div> 
                            </div>  
                        </div>
                    </div>
                </form>
                <?php 
                if (isset($_POST['simpan'])) 
                {
                    $nama_pelanggan      = $_POST['nama_pelanggan'];
                    $nohp_pelanggan          = $_POST['nohp_pelanggan'];
                    $email_pelanggan          = $_POST['email_pelanggan'];
                    $alamat_pelanggan      = $_POST['alamat_pelanggan']; 
                    $username_pelanggan    = $_POST['username_pelanggan'];  
                    $password_pelanggan    = $_POST['password_pelanggan'];  
                    $status_pelanggan    = $_POST['status_pelanggan']; 
                    { 
                        $con->query("UPDATE pelanggan SET nama_pelanggan='$nama_pelanggan',
                                                         nohp_pelanggan='$nohp_pelanggan',
                                                         email_pelanggan='$email_pelanggan',
                                                         alamat_pelanggan='$alamat_pelanggan',
                                                         username_pelanggan='$username_pelanggan',
                                                         password_pelanggan='$password_pelanggan',
                                                         status_pelanggan='$status_pelanggan' WHERE id_pelanggan='$_GET[id_pelanggan]'"); 
                    } 
                    echo "<script>alert('Data berhasil diubah');</script>";
                    echo "<script>location='?page=pelanggan';</script>";
                }
                ?>
            </div>
        </div>
    </div> 
</div>