<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Admin</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="index.php">Beranda</a></li>
                    <li class="breadcrumb-item">Data Master</li>
                    <li class="breadcrumb-item">Admin</li>
                    <li class="breadcrumb-item active">Tambah Data</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Tambah Data</h5>
            </div>
            <div class="card-body">
                <form class="needs-validation" novalidate method="POST" enctype="multipart/form-data"> 
                    <div class="row">
                        <div class="col-md-6">
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label">Karyawan</label>
                                <div class="col-sm-9">
                                    <select class="js-example-basic-single" name="id_karyawan">
                                        <option>Pilih Karyawan</option> 
                                        <?php
                                        $sql=mysqli_query($con, "SELECT * FROM karyawan");
                                        while ($pang=mysqli_fetch_array($sql))
                                        {
                                            echo "<option value='$pang[id_karyawan]'>$pang[nama_karyawan]</option>";
                                        }
                                        ?>
                                    </select> 
                                </div>
                            </div> 
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label">Username</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="username" required> 
                                </div>
                            </div> 
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label">Password</label>
                                <div class="col-sm-9">
                                    <input type="password" class="form-control" name="password" required>
                                </div>
                            </div>  
                        </div>
                        <div class="col-md-6">
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label">Level</label>
                                <div class="col-sm-9">
                                    <select class="js-example-basic-single" name="level">
                                        <option>Pilih Level</option> 
                                        <option value="Admin">Admin</option> 
                                        <option value="Pimpinan">Pimpinan</option> 
                                    </select> 
                                </div>
                            </div> 
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label">Status</label>
                                <div class="col-sm-9">
                                    <select class="js-example-basic-single" name="status">
                                        <option>Pilih Status</option>  
                                        <option value="Aktif">Aktif</option>
                                        <option value="Non Aktif">Non Aktif</option>
                                    </select> 
                                </div>
                            </div> 
                            <div class="row">
                                <label class="col-sm-3 col-form-label">&nbsp;</label>
                                <div class="col-sm-9">
                                    <input type="submit" name="simpan" value="Simpan" class="btn btn-sm btn-primary"> 
                                    <a href="?page=admin" class="btn btn-danger btn-sm"> Kembali</a>
                                </div> 
                            </div>  
                        </div>
                    </div>
                </form>
                <?php 
                if (isset($_POST['simpan'])) 
                {
                    $id_karyawan    = $_POST['id_karyawan'];
                    $username       = $_POST['username'];
                    $password       = $_POST['password'];
                    $level          = $_POST['level']; 
                    $status         = $_POST['status'];  

                    $ambil = $con->query("SELECT * FROM admin WHERE id_karyawan='$id_karyawan'");
                    $yangcocok = mysqli_num_rows($ambil);
                    if ($yangcocok==1) 
                    {
                        echo "<script>alert('Data sudah ada.');</script>";
                        echo "<script>location='?page=admin&aksi=tambah';</script>";
                    }
                    else
                    {
                        $con->query("INSERT INTO admin
                            (id_karyawan,username,password,level,status)
                            VALUES ('$id_karyawan','$username','$password','$level','$status') ");

                        echo "<script>alert('Data berhasil ditambahkan.');</script>";
                        echo "<script>location='?page=admin';</script>";
                    }
                }
                ?> 
            </div>
        </div>
    </div> 
</div>