<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Admin</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="index.php">Beranda</a></li>
                    <li class="breadcrumb-item">Data Master</li>
                    <li class="breadcrumb-item active">Admin</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Data Admin
                    <div class="float-end">
                        <a href="?page=admin&aksi=tambah" title="Tambah Data" class="btn btn-soft-info btn-sm"> <i class="ri-add-box-line"></i></a>
                    </div>
                </h5>
            </div>
            <div class="card-body">
                <table id="fixed-header" class="table table-bordered dt-responsive nowrap table-striped align-middle" style="width:100%">
                    <thead>
                        <tr>
                            <th class="text-center" style="width: 10px;">No.</th>
                            <th>Karyawan</th>
                            <th>Akun</th>
                            <th>Level</th>
                            <th>Status</th> 
                            <th class="text-center" style="width: 10px;">#</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $nomor=1; ?>
                        <?php $ambil=$con->query("SELECT * FROM admin NATURAL JOIN karyawan ORDER BY id_admin DESC"); ?>
                        <?php while ($pecah = $ambil->fetch_assoc()) { 
                            $tgl = tgl_indo($pecah['tgl_lahir']); ?>
                        <tr> 
                            <td><?php echo $nomor; ?></td>
                            <td><?php echo $pecah['nama_karyawan']; ?></td>   
                            <td>U : <?php echo $pecah['username']; ?> | P : <?php echo $pecah['password']; ?></td>   
                            <td><?php echo $pecah['level']; ?></td>   
                            <td><?php echo $pecah['status']; ?></td>   
                            <td>
                                <a href="?page=admin&aksi=ubah&id_admin=<?php echo $pecah['id_admin'] ?>" title="Ubah Data" class="btn btn-soft-success btn-sm"> <i class=" ri-edit-2-line"></i></a>
                                <a onclick="return confirm('Yakin Menghapus Data - <?php echo $pecah['nama_karyawan']; ?> ?')" href="?page=admin&aksi=hapus&id_admin=<?php echo $pecah['id_admin'] ?>" title="Hapus Data" class="btn btn-soft-danger btn-sm"> <i class="ri-delete-bin-fill"></i></a>
                            </td> 
                        </tr>
                        <?php $nomor++; ?>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div> 
</div>