<?php 
$id_admin = $_GET['id_admin'];
$ambil = $con->query("SELECT * FROM admin WHERE id_admin ='$_GET[id_admin]'");
$pecah = $ambil->fetch_assoc(); 
$level = $pecah['level'];
$status = $pecah['status'];
?>


<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Admin</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="index.php">Beranda</a></li>
                    <li class="breadcrumb-item">Data Master</li>
                    <li class="breadcrumb-item">Admin</li>
                    <li class="breadcrumb-item active">Ubah Data</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Ubah Data</h5>
            </div>
            <div class="card-body">
                <form class="needs-validation" novalidate method="POST" enctype="multipart/form-data"> 
                    <div class="row">
                        <div class="col-md-6">
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label">Karyawan</label>
                                <div class="col-sm-9">
                                    <select class="js-example-basic-single" name="id_karyawan">
                                        <option>Pilih Karyawan</option> 
                                        <?php
                                        $sql_kar=mysqli_query($con, "SELECT * FROM karyawan");
                                        while ($kar=mysqli_fetch_array($sql_kar))
                                        {
                                            $selected = ($kar['id_karyawan'] == $pecah['id_karyawan']) ?
                                            'selected="selected"'  : "";
                                            echo "<option value='$kar[id_karyawan]' $selected>$kar[nama_karyawan]</option>";
                                        }
                                        ?>
                                    </select> 
                                </div>
                            </div> 
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label">Username</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="username" value="<?php echo $pecah['username'] ?>" required> 
                                </div>
                            </div> 
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label">Password</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="password" value="<?php echo $pecah['password'] ?>" required>
                                </div>
                            </div>  
                        </div>
                        <div class="col-md-6">
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label">Level</label>
                                <div class="col-sm-9">
                                    <select class="js-example-basic-single" name="level">
                                        <option>Pilih Level</option> 
                                        <option value="Admin" <?php if ($level=='Admin') { echo "selected"; } ?>>Admin</option>
                                        <option value="Pimpinan" <?php if ($level=='Pimpinan') { echo "selected"; } ?>>Pimpinan</option>
                                    </select> 
                                </div>
                            </div> 
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label">Status</label>
                                <div class="col-sm-9">
                                    <select class="js-example-basic-single" name="status">
                                        <option>Pilih Status</option>  
                                        <option value="Aktif" <?php if ($status=='Aktif') { echo "selected"; } ?>>Aktif</option>
                                        <option value="Non Aktif" <?php if ($status=='Non Aktif') { echo "selected"; } ?>>Non Aktif</option>
                                    </select> 
                                </div>
                            </div> 
                            <div class="row">
                                <label class="col-sm-3 col-form-label">&nbsp;</label>
                                <div class="col-sm-9">
                                    <input type="submit" name="simpan" value="Simpan" class="btn btn-sm btn-primary"> 
                                    <a href="?page=admin" class="btn btn-danger btn-sm"> Kembali</a>
                                </div> 
                            </div>  
                        </div>
                    </div>
                </form>
                <?php 
                if (isset($_POST['simpan'])) 
                {
                    $id_karyawan = $_POST['id_karyawan'];
                    $username    = $_POST['username'];
                    $password    = $_POST['password'];
                    $level       = $_POST['level']; 
                    $status      = $_POST['status'];  
                    { 
                        $con->query("UPDATE admin SET id_karyawan='$id_karyawan',
                                                      username='$username',
                                                      password='$password',
                                                      level='$level',
                                                      status='$status' WHERE id_admin='$_GET[id_admin]'"); 
                    } 
                    echo "<script>alert('Data berhasil diubah');</script>";
                    echo "<script>location='?page=admin';</script>";
                }
                ?>
            </div>
        </div>
    </div> 
</div>