<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Menu Catering</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="index.php">Beranda</a></li>
                    <li class="breadcrumb-item">Data Master</li>
                    <li class="breadcrumb-item">Menu Catering</li>
                    <li class="breadcrumb-item active">Tambah Data</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Tambah Data</h5>
            </div>
            <div class="card-body">
                <form class="needs-validation" novalidate method="POST" enctype="multipart/form-data"> 
                    <div class="row">
                        <div class="col-md-6">
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label">Nama Menu</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="menu" autofocus required> 
                                </div>
                            </div> 
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label">Kategori</label>
                                <div class="col-sm-9">
                                    <select class="js-example-basic-single" name="id_kategori">
                                        <option>Pilih Kategori</option> 
                                        <?php
                                        $sql=mysqli_query($con, "SELECT * FROM kategori");
                                        while ($pang=mysqli_fetch_array($sql))
                                        {
                                            echo "<option value='$pang[id_kategori]'>$pang[kategori]</option>";
                                        }
                                        ?>
                                    </select> 
                                </div>
                            </div> 
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label">Harga Menu</label>
                                <div class="col-sm-9">
                                    <div class="input-group">
                                        <span class="input-group-text">Rp.</span>
                                        <input type="text" class="form-control" name="harga" id="harga" onkeypress="return angka(event);" onkeyup="sum()" style="text-align: right;" required>  
                                    </div> 
                                </div>
                            </div>  
                        </div>
                        <div class="col-md-6">
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label">Status</label>
                                <div class="col-sm-9">
                                    <select class="js-example-basic-single" name="status_menu">
                                        <option>Pilih Status</option>  
                                        <option value="Aktif">Aktif</option>
                                        <option value="Non Aktif">Non Aktif</option>
                                    </select> 
                                </div>
                            </div>  
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label">Foto Menu 1</label>
                                <div class="col-sm-9">
                                    <input type="file" class="form-control" name="foto" required>
                                </div>
                            </div>
                            
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label">Foto Menu 2</label>
                                <div class="col-sm-9">
                                    <input type="file" class="form-control" name="foto_2" required>
                                </div>
                            </div>
                            
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label">Foto Menu 3</label>
                                <div class="col-sm-9">
                                    <input type="file" class="form-control" name="foto_3" required>
                                </div>
                            </div>
                            <div class="row">
                                <label class="col-sm-3 col-form-label">&nbsp;</label>
                                <div class="col-sm-9">
                                    <input type="submit" name="simpan" value="Simpan" class="btn btn-sm btn-primary"> 
                                    <a href="?page=menu" class="btn btn-danger btn-sm"> Kembali</a>
                                </div> 
                            </div>  
                        </div>
                    </div>
                </form>
                <?php 
                if (isset($_POST['simpan'])) 
                {
                    $menu        = $_POST['menu'];
                    $id_kategori = $_POST['id_kategori'];

                    $harga1     = $_POST['harga'];
                    $harga      = str_replace(".", "", $harga1); 

                    $status_menu = $_POST['status_menu']; 
                    $foto       = $_FILES['foto']['name'];
                    $lokasi1     = $_FILES['foto']['tmp_name'];
                    move_uploaded_file($lokasi1, "assets/foto/".$foto); 

                    $foto_2       = $_FILES['foto_2']['name'];
                    $lokasi3     = $_FILES['foto_2']['tmp_name'];
                    move_uploaded_file($lokasi3, "assets/foto/".$foto_2);  

                    $foto_3       = $_FILES['foto_3']['name'];
                    $lokasi2     = $_FILES['foto_3']['tmp_name'];
                    move_uploaded_file($lokasi2, "assets/foto/".$foto_3);  

                    $ambil = $con->query("SELECT * FROM menu WHERE menu='$menu'");
                    $yangcocok = mysqli_num_rows($ambil);
                    if ($yangcocok==1) 
                    {
                        echo "<script>alert('Data sudah ada.');</script>";
                        echo "<script>location='?page=menu&aksi=tambah';</script>";
                    }
                    else
                    {
                        $con->query("INSERT INTO menu
                            (menu,id_kategori,harga,status_menu,foto,foto_2,foto_3)
                            VALUES ('$menu','$id_kategori','$harga','$status_menu','$foto','$foto_2','$foto_3') ");

                        echo "<script>alert('Data berhasil ditambahkan.');</script>";
                        echo "<script>location='?page=menu';</script>";
                    }
                }
                ?> 
            </div>
        </div>
    </div> 
</div>

<script type="text/javascript">
    function angka(evt) 
    {
        var charCode = (evt.which) ? evt.which : event.keyCode
        if (charCode > 31 && (charCode < 48 || charCode > 57)) 
        {
            return false;
        }
        return true;
    }
</script>


<script type="text/javascript">

    var harga = document.getElementById('harga');
    harga.addEventListener('keyup', function(e)
    {
        harga.value = formatRupiah(this.value);
    }); 
    
    /* Fungsi */
    function formatRupiah(angka, prefix)
    {
        var number_string = angka.replace(/[^,\d]/g, '').toString(),
            split    = number_string.split(','),
            sisa     = split[0].length % 3,
            rupiah     = split[0].substr(0, sisa),
            ribuan     = split[0].substr(sisa).match(/\d{3}/gi);
            
        if (ribuan) {
            separator = sisa ? '.' : '';
            rupiah += separator + ribuan.join('.');
        }
        
        rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
        return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
    } 

</script> 