<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Menu Catering</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="index.php">Beranda</a></li>
                    <li class="breadcrumb-item">Data Master</li>
                    <li class="breadcrumb-item active">Menu Catering</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Data Menu Catering
                    <div class="float-end">
                        <a href="?page=menu&aksi=tambah" title="Tambah Data" class="btn btn-soft-info btn-sm"> <i class="ri-add-box-line"></i></a>
                    </div>
                </h5>
            </div>
            <div class="card-body">
                <table id="fixed-header" class="table table-bordered dt-responsive nowrap table-striped align-middle" style="width:100%">
                    <thead>
                        <tr>
                            <th class="text-center" style="width: 10px;">No.</th>
                            <th>Menu</th>
                            <th>Kategori</th>
                            <th class="text-end">Harga</th> 
                            <th>Status</th>
                            <th class="text-center" style="width: 15px;">#</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $nomor=1; ?>
                        <?php $ambil=$con->query("SELECT * FROM menu NATURAL JOIN kategori ORDER BY id_menu DESC"); ?>
                        <?php while ($pecah = $ambil->fetch_assoc()) { 
                            $tgl = tgl_indo($pecah['tgl_lahir']); ?>
                        <tr> 
                            <td><?php echo $nomor; ?></td>
                            <td><?php echo $pecah['menu']; ?></td>   
                            <td><?php echo $pecah['kategori']; ?></td>   
                            <td class="text-end"><?php echo number_format($pecah['harga'], 0, ',','.') ?></td>    
                            <td><?php echo $pecah['status_menu']; ?></td>  
                            <td>
                                <a href="?page=menu&aksi=ubah&id_menu=<?php echo $pecah['id_menu'] ?>" title="Ubah Data" class="btn btn-soft-success btn-sm"> <i class=" ri-edit-2-line"></i></a>
                                <a onclick="return confirm('Yakin Menghapus Data - <?php echo $pecah['menu']; ?> ?')" href="?page=menu&aksi=hapus&id_menu=<?php echo $pecah['id_menu'] ?>" title="Hapus Data" class="btn btn-soft-danger btn-sm"> <i class="ri-delete-bin-fill"></i></a>
                            </td> 
                        </tr>
                        <?php $nomor++; ?>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div> 
</div>