<?php
$ambil = $con->query("SELECT * FROM menu WHERE id_menu = '$_GET[id_menu]'");
$pecah = $ambil->fetch_assoc();
$foto = $pecah['foto'];
if (file_exists("assets/foto/$foto"))
{
    unlink("assets/foto/$foto");
}

$con->query("DELETE FROM menu WHERE id_menu = '$_GET[id_menu]'");

echo "<script>alert('Data berhasil dihapus?');</script>";
echo "<script>location='?page=menu';</script>";

?> 