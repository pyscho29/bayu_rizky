<?php
$ambil = $con->query("SELECT * FROM karyawan WHERE id_karyawan = '$_GET[id_karyawan]'");
$pecah = $ambil->fetch_assoc();
$ft_kar = $pecah['ft_kar'];
if (file_exists("assets/foto/$ft_kar"))
{
    unlink("assets/foto/$ft_kar");
}

$con->query("DELETE FROM karyawan WHERE id_karyawan = '$_GET[id_karyawan]'");

echo "<script>alert('Data berhasil dihapus?');</script>";
echo "<script>location='?page=karyawan';</script>";

?> 