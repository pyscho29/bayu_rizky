<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Karyawan</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="index.php">Beranda</a></li>
                    <li class="breadcrumb-item">Data Master</li>
                    <li class="breadcrumb-item active">Karyawan</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Data Karyawan
                    <div class="float-end">
                        <a href="?page=karyawan&aksi=tambah" title="Tambah Data" class="btn btn-soft-info btn-sm"> <i class="ri-add-box-line"></i></a>
                    </div>
                </h5>
            </div>
            <div class="card-body">
                <table id="fixed-header" class="table table-bordered dt-responsive nowrap table-striped align-middle" style="width:100%">
                    <thead>
                        <tr>
                            <th class="text-center" style="width: 10px;">No.</th>
                            <th>Nama</th>
                            <th>Tempat, Tanggal Lahir</th>
                            <th>Telp</th>
                            <th>Alamat</th>
                            <th class="text-center">Foto</th> 
                            <th class="text-center" style="width: 10px;">#</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $nomor=1; ?>
                        <?php $ambil=$con->query("SELECT * FROM karyawan ORDER BY id_karyawan DESC"); ?>
                        <?php while ($pecah = $ambil->fetch_assoc()) { 
                            $tgl = tgl_indo($pecah['tgl_lahir']); ?>
                        <tr> 
                            <td><?php echo $nomor; ?></td>
                            <td><?php echo $pecah['nama_karyawan']; ?></td>   
                            <td><?php echo $pecah['tmp_lahir']; ?>, <?php echo $tgl ?></td>   
                            <td><?php echo $pecah['nohp_karyawan']; ?></td>   
                            <td><?php echo $pecah['alamat_karyawan']; ?></td>  
                            <td class="text-center">
                                <div class="row gallery-wrapper">
                                <div class="element-item">
                                    <div class="gallery-box card">
                                        <div class="gallery-container">
                                            <a class="image-popup" href="assets/foto/<?php echo $pecah['ft_kar'] ?>" title="">
                                                Lihat Foto 
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <a href="?page=karyawan&aksi=ubah&id_karyawan=<?php echo $pecah['id_karyawan'] ?>" title="Ubah Data" class="btn btn-soft-success btn-sm"> <i class=" ri-edit-2-line"></i></a>
                                <a onclick="return confirm('Yakin Menghapus Data - <?php echo $pecah['nama_karyawan']; ?> ?')" href="?page=karyawan&aksi=hapus&id_karyawan=<?php echo $pecah['id_karyawan'] ?>" title="Hapus Data" class="btn btn-soft-danger btn-sm"> <i class="ri-delete-bin-fill"></i></a>
                            </td> 
                        </tr>
                        <?php $nomor++; ?>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div> 
</div>