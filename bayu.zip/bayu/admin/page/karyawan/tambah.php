<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Karyawan</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="index.php">Beranda</a></li>
                    <li class="breadcrumb-item">Data Master</li>
                    <li class="breadcrumb-item">Karyawan</li>
                    <li class="breadcrumb-item active">Tambah Data</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Tambah Data</h5>
            </div>
            <div class="card-body">
                <form class="needs-validation" novalidate method="POST" enctype="multipart/form-data"> 
                    <div class="row">
                        <div class="col-md-6">
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label">Nama</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="nama_karyawan" autofocus required> 
                                </div>
                            </div> 
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label">Tempat Lahir</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="tmp_lahir" required> 
                                </div>
                            </div> 
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label">Tanggal Lahir</label>
                                <div class="col-sm-9">
                                    <input type="date" class="form-control" name="tgl_lahir" required>
                                </div>
                            </div>  
                        </div>
                        <div class="col-md-6">
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label">Nomor HP</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="nohp_karyawan" required> 
                                </div>
                            </div> 
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label">Alamat</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="alamat_karyawan" required> 
                                </div>
                            </div> 
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label">Foto</label>
                                <div class="col-sm-9">
                                    <input type="file" class="form-control" name="ft_kar" required>
                                </div>
                            </div>
                            <div class="row">
                                <label class="col-sm-3 col-form-label">&nbsp;</label>
                                <div class="col-sm-9">
                                    <input type="submit" name="simpan" value="Simpan" class="btn btn-sm btn-primary"> 
                                    <a href="?page=karyawan" class="btn btn-danger btn-sm"> Kembali</a>
                                </div> 
                            </div>  
                        </div>
                    </div>
                </form>
                <?php 
                if (isset($_POST['simpan'])) 
                {
                    $nama_karyawan      = $_POST['nama_karyawan'];
                    $tmp_lahir          = $_POST['tmp_lahir'];
                    $tgl_lahir          = $_POST['tgl_lahir'];
                    $nohp_karyawan      = $_POST['nohp_karyawan']; 
                    $alamat_karyawan    = $_POST['alamat_karyawan']; 
                    $ft_kar             = $_FILES['ft_kar']['name'];
                    $lokasi             = $_FILES['ft_kar']['tmp_name'];
                    move_uploaded_file($lokasi, "assets/foto/".$ft_kar);

                    $ambil = $con->query("SELECT * FROM karyawan WHERE nama_karyawan='$nama_karyawan'");
                    $yangcocok = mysqli_num_rows($ambil);
                    if ($yangcocok==1) 
                    {
                        echo "<script>alert('Data sudah ada.');</script>";
                        echo "<script>location='?page=karyawan&aksi=tambah';</script>";
                    }
                    else
                    {
                        $con->query("INSERT INTO karyawan
                            (nama_karyawan,tmp_lahir,tgl_lahir,nohp_karyawan,alamat_karyawan,ft_kar)
                            VALUES ('$nama_karyawan','$tmp_lahir','$tgl_lahir','$nohp_karyawan','$alamat_karyawan','$ft_kar') ");

                        echo "<script>alert('Data berhasil ditambahkan.');</script>";
                        echo "<script>location='?page=karyawan';</script>";
                    }
                }
                ?> 
            </div>
        </div>
    </div> 
</div>