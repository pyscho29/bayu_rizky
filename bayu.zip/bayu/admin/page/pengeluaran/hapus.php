<?php
$con->query("DELETE FROM pengeluaran WHERE id_pengeluaran = '$_GET[id_pengeluaran]'");

echo "<script>alert('Data berhasil dihapus?');</script>";
echo "<script>location='?page=pengeluaran';</script>";
?> 