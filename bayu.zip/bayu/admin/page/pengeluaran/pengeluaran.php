<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Pengeluaran</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="index.php">Beranda</a></li>
                    <li class="breadcrumb-item active">Pengeluaran</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Data Pengeluaran
                    <div class="float-end">
                        <a href="?page=pengeluaran&aksi=tambah" title="Tambah Data" class="btn btn-soft-info btn-sm"> <i class="ri-add-box-line"></i></a>
                    </div>
                </h5>
            </div>
            <div class="card-body">
                <table id="fixed-header" class="table table-bordered dt-responsive nowrap table-striped align-middle" style="width:100%">
                    <thead>
                        <tr>
                            <th class="text-center" style="width: 10px;">No.</th>
                            <th class="text-end">PLN</th>
                            <th class="text-end">PDAM</th>
                            <th class="text-end">Gaji</th>
                            <th class="text-end">Jumlah Kotor</th>
                            <th>Periode</th>
                            <th class="text-center" style="width: 10px;">#</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $nomor=1; ?>
                        <?php $ambil=$con->query("SELECT * FROM pengeluaran ORDER BY id_pengeluaran DESC"); ?>
                        <?php while ($pecah = $ambil->fetch_assoc()) { 
                            $bln = getBulan($pecah['bulan']);
                            $tgl = tgl_indo($pecah['tgl_lahir']); ?>
                        <tr> 
                            <td><?php echo $nomor; ?></td>
                            <td class="text-end"><?php echo number_format($pecah['pln'], 0, ',','.') ?></td>      
                            <td class="text-end"><?php echo number_format($pecah['pdam'], 0, ',','.') ?></td>      
                            <td class="text-end"><?php echo number_format($pecah['gaji'], 0, ',','.') ?></td>      
                            <td class="text-end"><?php echo number_format($pecah['jkotor'], 0, ',','.') ?></td>      
                            <td><?php echo $bln; ?> - <?php echo $pecah['tahun']; ?></td>   
                            <td>
                                <a onclick="return confirm('Yakin Menghapus Data - <?php echo $bln; ?> - <?php echo $pecah['tahun']; ?> ?')" href="?page=pengeluaran&aksi=hapus&id_pengeluaran=<?php echo $pecah['id_pengeluaran'] ?>" title="Hapus Data" class="btn btn-soft-danger btn-sm"> <i class="ri-delete-bin-fill"></i></a>
                            </td> 
                        </tr>
                        <?php $nomor++; ?>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div> 
</div>