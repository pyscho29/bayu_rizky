<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Pengeluaran</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="index.php">Beranda</a></li>
                    <li class="breadcrumb-item">Pengeluaran</li>
                    <li class="breadcrumb-item active">Tambah Data</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Tambah Data</h5>
            </div>
            <div class="card-body">
                <form class="needs-validation" novalidate method="POST" enctype="multipart/form-data"> 
                    <div class="row">
                        <div class="col-md-6">
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label">PLN</label>
                                <div class="col-sm-9">
                                    <div class="input-group">
                                        <span class="input-group-text">Rp.</span>
                                        <input class="form-control" type="text" name="pln" id="pln" style="text-align: right;" onkeypress="return angka(event);" onkeyup="sum();" required autofocus>
                                    </div>
                                </div>
                            </div> 
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label">PDAM</label>
                                <div class="col-sm-9">
                                    <div class="input-group">
                                        <span class="input-group-text">Rp.</span>
                                        <input class="form-control" type="text" name="pdam" id="pdam" style="text-align: right;" onkeypress="return angka(event);" onkeyup="sum();" required >
                                    </div>
                                </div>
                            </div> 
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label">Gaji Karyawan</label>
                                <div class="col-sm-9">
                                    <div class="input-group">
                                        <span class="input-group-text">Rp.</span>
                                        <input class="form-control" type="text" name="gaji" id="gaji" style="text-align: right;" onkeypress="return angka(event);" onkeyup="sum();" required >
                                    </div>
                                </div>
                            </div>  
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label">Jumlah Kotor</label>
                                <div class="col-sm-9">
                                    <div class="input-group">
                                        <span class="input-group-text">Rp.</span>
                                        <input class="form-control" type="text" name="jkotor" id="jkotor" style="text-align: right;" onkeypress="return angka(event);" onkeyup="sum();" required readonly>
                                    </div>
                                </div>
                            </div>    
                        </div>
                        <div class="col-md-6">
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label">Bulan</label>
                                <div class="col-sm-9">
                                    <select class="js-example-basic-single" name="bulan" required>
                                        <option></option>
                                        <option value='01'>Januari</option>
                                        <option value='02'>Februari</option>
                                        <option value='03'>Maret</option>
                                        <option value='04'>April</option>
                                        <option value='05'>Mei</option>
                                        <option value='06'>Juni</option>
                                        <option value='07'>Juli</option>
                                        <option value='08'>Agustus</option>
                                        <option value='09'>September</option>
                                        <option value='10'>Oktober</option>
                                        <option value='11'>November</option>
                                        <option value='12'>Desember</option>
                                    </select>
                                </div>
                            </div> 
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label">Tahun</label>
                                <div class="col-sm-9">
                                    <select class="js-example-basic-single" name="tahun" required>
                                        <option></option>
                                        <?php
                                        $mulai = date('Y') - 6;
                                        for ($i= $mulai;$i<$mulai + 100;$i++){
                                            $sel = $i == date('Y') ? ' selected = "selected"' : '';
                                             echo '<option value="'.$i.'"'.$sel.'>'.$i.'</option>';
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>   
                            <div class="row">
                                <label class="col-sm-3 col-form-label">&nbsp;</label>
                                <div class="col-sm-9">
                                    <input type="submit" name="simpan" value="Simpan" class="btn btn-sm btn-primary"> 
                                    <a href="?page=pengeluaran" class="btn btn-danger btn-sm"> Kembali</a>
                                </div> 
                            </div>  
                        </div>
                    </div>
                </form>
                <?php 
                if (isset($_POST['simpan'])) 
                {
                    $pln1         = $_POST['pln'];
                    $pln          = str_replace(".", "", $pln1);

                    $pdam1         = $_POST['pdam'];
                    $pdam          = str_replace(".", "", $pdam1);

                    $gaji1         = $_POST['gaji'];
                    $gaji          = str_replace(".", "", $gaji1);

                    $jkotor1         = $_POST['jkotor'];
                    $jkotor          = str_replace(".", "", $jkotor1);                    

                    $bulan      = $_POST['bulan'];
                    $tahun          = $_POST['tahun']; 

                    $ambil = $con->query("SELECT * FROM pengeluaran WHERE bulan='$bulan' AND tahun='$tahun'");
                    $yangcocok = mysqli_num_rows($ambil);
                    if ($yangcocok==1) 
                    {
                        echo "<script>alert('Data sudah ada.');</script>";
                        echo "<script>location='?page=pengeluaran&aksi=tambah';</script>";
                    }
                    else
                    {
                        $con->query("INSERT INTO pengeluaran
                            (pln,pdam,gaji,jkotor,bulan,tahun)
                            VALUES ('$pln','$pdam','$gaji','$jkotor','$bulan','$tahun') ");

                        echo "<script>alert('Data berhasil ditambahkan.');</script>";
                        echo "<script>location='?page=pengeluaran';</script>";
                    }
                }
                ?> 
            </div>
        </div>
    </div> 
</div>

<script type="text/javascript">

    function angka(evt) 
    {
        var charCode = (evt.which) ? evt.which : event.keyCode
        if (charCode > 31 && (charCode < 48 || charCode > 57)) 
        {
            return false;
        }
        return true;
    }

    var pln = document.getElementById('pln');
    pln.addEventListener('keyup', function(e)
    {
        pln.value = formatRupiah(this.value);
    });

    var pdam = document.getElementById('pdam');
    pdam.addEventListener('keyup', function(e)
    {
        pdam.value = formatRupiah(this.value);
    });

    var gaji = document.getElementById('gaji');
    gaji.addEventListener('keyup', function(e)
    {
        gaji.value = formatRupiah(this.value);
    });  

    var jkotor = document.getElementById('jkotor');
    jkotor.addEventListener('keyup', function(e)
    {
        jkotor.value = formatRupiah(this.value);
    });   
    
    /* Fungsi */
    function formatRupiah(angka, prefix)
    {
        var number_string = angka.replace(/[^,\d]/g, '').toString(),
            split    = number_string.split(','),
            sisa     = split[0].length % 3,
            rupiah     = split[0].substr(0, sisa),
            ribuan     = split[0].substr(sisa).match(/\d{3}/gi);
            
        if (ribuan) {
            separator = sisa ? '.' : '';
            rupiah += separator + ribuan.join('.');
        }
        
        rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
        return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
    }

    function sum()
    {
        //tunjangan
        var pln = document.getElementById('pln').value;
        var pdam = document.getElementById('pdam').value;  
        var gaji = document.getElementById('gaji').value;
        var jkotor = document.getElementById('jkotor').value;     

        if(pln=="")
        {
            var pln = 0;
        }else{
            var pln = parseInt(pln.split(".").join(""));
        }

        if(pdam=="")
        {
            var pdam =0;
        }else{
            var pdam = parseInt(pdam.split(".").join(""));
        }

        if(gaji=="")
        {
            var gaji =0;
        }else{
            var gaji = parseInt(gaji.split(".").join(""));
        }

        if(jkotor=="")
        {
            var jkotor =0;
        }else{
            var jkotor = parseInt(jkotor.split(".").join(""));
        } 


        var jkotor = pln+pdam+gaji;

        if(!isNaN(jkotor))
        {
            document.getElementById('jkotor').value = jkotor.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
        }    
    
    }

</script> 