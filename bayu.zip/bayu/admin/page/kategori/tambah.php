<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Kategori</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="index.php">Beranda</a></li>
                    <li class="breadcrumb-item">Data Master</li>
                    <li class="breadcrumb-item">Kategori</li>
                    <li class="breadcrumb-item active">Tambah Data</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Tambah Data</h5>
            </div>
            <div class="card-body">
                <form class="needs-validation" novalidate method="POST" enctype="multipart/form-data"> 
                    <div class="row">
                        <div class="col-md-12">
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label">Kategori</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="kategori" required> 
                                </div>
                            </div>  
                            <div class="row">
                                <label class="col-sm-3 col-form-label">&nbsp;</label>
                                <div class="col-sm-9">
                                    <input type="submit" name="simpan" value="Simpan" class="btn btn-sm btn-primary"> 
                                    <a href="?page=kategori" class="btn btn-danger btn-sm"> Kembali</a>
                                </div> 
                            </div>  
                        </div> 
                    </div>
                </form>
                <?php 
                if (isset($_POST['simpan'])) 
                {
                    $kategori    = $_POST['kategori'];   

                    $ambil = $con->query("SELECT * FROM kategori WHERE kategori='$kategori'");
                    $yangcocok = mysqli_num_rows($ambil);
                    if ($yangcocok==1) 
                    {
                        echo "<script>alert('Data sudah ada.');</script>";
                        echo "<script>location='?page=kategori&aksi=tambah';</script>";
                    }
                    else
                    {
                        $con->query("INSERT INTO kategori (kategori) VALUES ('$kategori') ");

                        echo "<script>alert('Data berhasil ditambahkan.');</script>";
                        echo "<script>location='?page=kategori';</script>";
                    }
                }
                ?> 
            </div>
        </div>
    </div> 
</div>