<?php 
$con->query("DELETE FROM kategori WHERE id_kategori = '$_GET[id_kategori]'");

echo "<script>alert('Data berhasil dihapus?');</script>";
echo "<script>location='?page=kategori';</script>";

?> 