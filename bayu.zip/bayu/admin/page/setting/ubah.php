<?php 
$id_meta = $_GET['id_meta'];
$ambil = $con->query("SELECT * FROM meta WHERE id_meta ='$_GET[id_meta]'");
$pecah = $ambil->fetch_assoc(); 
?>

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Setting</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="index.php">Beranda</a></li>
                    <li class="breadcrumb-item">Setting</li>
                    <li class="breadcrumb-item active">Ubah Data</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Ubah Data</h5>
            </div>
            <form class="row mb-3 needs-validation" novalidate method="POST" enctype="multipart/form-data">
                <div class="card-body">
                    <table class="table dt-responsive nowrap table-striped table-borderless" style="width:100%">
                         <tr>
                            <td align="right" style="vertical-align: middle;">Judul </td>
                            <td>
                                <input type="text" class="form-control" name="judul_meta" value="<?php echo $judul ?>" required>
                            </td>                                   
                        </tr>      
                        <tr>
                            <td align="right" style="vertical-align: middle;">Alamat </td>
                            <td>
                                <input type="text" class="form-control" size="100" name="alamat_meta" value="<?php echo $alamat ?>" required>
                            </td>                                   
                        </tr>  
                        <tr>
                            <td align="right" style="vertical-align: middle;">Email </td>
                            <td>
                                <input type="text" class="form-control" name="email_meta" value="<?php echo $email ?>" required>
                            </td>                                   
                        </tr>  
                        <tr>
                            <td align="right" style="vertical-align: middle;">Telepon </td>
                            <td>
                                <input type="number" class="form-control" name="telp_meta" value="<?php echo $telp ?>" required>
                            </td>                                   
                        </tr>  
                        <tr>
                            <td align="right" style="vertical-align: middle;">Nama Pimpinan</td>
                            <td>
                                <input type="text" class="form-control" name="nama_pimpinan" value="<?php echo $pimpinan ?>" required>
                            </td>                                   
                        </tr> 
                        <tr>
                            <td align="right" style="vertical-align: middle;">Singkatan</td>
                            <td>
                                <input type="text" class="form-control" name="singkatan" value="<?php echo $singkatan ?>" required>
                            </td>                                   
                        </tr>  
                        <tr>
                            <td align="right">Logo </td>
                            <td>
                                <img src="assets/<?php echo $logo; ?>" class="rounded border" width="200"> <br> <br>
                                <input type="file" name="logo_meta" class="form-control">
                                <span class="text-danger">*) Kosongkan atau lewati apabila tidak diganti</span>
                            </td>                                   
                        </tr>  
                        <tr>
                            <td align="right">&nbsp; </td>
                            <td>
                                <input type="submit" name="simpan" value="Ubah Data" class="btn btn-success btn-sm">
                            </td>                                   
                        </tr>   
                    </table>
                </div>
            </form>
            <?php 
            if (isset($_POST['simpan']))
            {
                $minor   = $_POST['minor'];
                $judul_meta   = $_POST['judul_meta'];
                $alamat_meta = $_POST['alamat_meta'];
                $email_meta      = $_POST['email_meta']; 
                $telp_meta      = $_POST['telp_meta']; 
                $nama_pimpinan      = $_POST['nama_pimpinan']; 
                $singkatan      = $_POST['singkatan']; 
                $logo_meta       = $_FILES['logo_meta']['name'];
                $lokasi     = $_FILES['logo_meta']['tmp_name'];
                if (!empty($lokasi)) 
                {
                    move_uploaded_file($lokasi, "assets/".$logo_meta);
                    $con->query("UPDATE meta SET judul_meta='$judul_meta',
                                                    alamat_meta='$alamat_meta',
                                                    email_meta='$email_meta',
                                                    telp_meta='$telp_meta',
                                                    nama_pimpinan='$nama_pimpinan',
                                                    singkatan='$singkatan',
                                                    logo_meta='$logo_meta' WHERE id_meta='$_GET[id_meta]'"); 
                }
                else
                {
                    $con->query("UPDATE meta SET judul_meta='$judul_meta',
                                                    alamat_meta='$alamat_meta',
                                                    email_meta='$email_meta',
                                                    telp_meta='$telp_meta',
                                                    singkatan='$singkatan',
                                                    nama_pimpinan='$nama_pimpinan' WHERE id_meta='$_GET[id_meta]'"); 
                }  

                echo "<script>alert('Data berhasil diubah');</script>";
                echo "<script>location='?page=setting';</script>";
            }
            ?>
        </div>
    </div> 
</div>