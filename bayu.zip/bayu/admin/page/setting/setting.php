<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Setting</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="index.php">Beranda</a></li>
                    <li class="breadcrumb-item active">Setting Website</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Setting Website
                    <div class="float-end">
                        <a href="?page=setting&aksi=ubah&id_meta=<?php echo $set['id_meta'] ?>" title="Ubah" class="btn btn-soft-info btn-sm"> <i class="ri-edit-2-line"> Ubah</i></a>
                    </div>
                </h5>
            </div>
            <div class="card-body">
                <table class="table dt-responsive nowrap table-striped table-borderless" style="width:100%">
                     <tr>
                        <td align="right" style="vertical-align: middle;">Judul </td>
                        <td>
                            <input type="text" class="form-control bg-light" name="judul" value="<?php echo $judul ?>" required readonly>
                        </td>                                   
                    </tr>      
                    <tr>
                        <td align="right" style="vertical-align: middle;">Alamat </td>
                        <td>
                            <input type="text" class="form-control bg-light" size="100" name="alamat_set" value="<?php echo $alamat ?>" required readonly>
                        </td>                                   
                    </tr>  
                    <tr>
                        <td align="right" style="vertical-align: middle;">Email </td>
                        <td>
                            <input type="text" class="form-control bg-light" name="email_set" value="<?php echo $email ?>" required readonly>
                        </td>                                   
                    </tr>  
                    <tr>
                        <td align="right" style="vertical-align: middle;">Telepon </td>
                        <td>
                            <input type="number" class="form-control bg-light" name="telp_set" value="<?php echo $telp ?>" required readonly>
                        </td>                                   
                    </tr>  
                    <tr>
                        <td align="right" style="vertical-align: middle;">Nama Pimpinan</td>
                        <td>
                            <input type="text" class="form-control bg-light" name="pimpinan" value="<?php echo $pimpinan ?>" required readonly>
                        </td>                                   
                    </tr> 
                    <tr>
                        <td align="right" style="vertical-align: middle;">Singkatan</td>
                        <td>
                            <input type="text" class="form-control bg-light" name="pimpinan" value="<?php echo $singkatan ?>" required readonly>
                        </td>                                   
                    </tr>   
                    <tr>
                        <td align="right">Logo </td>
                        <td>
                            <img src="assets/<?php echo $logo; ?>" class="rounded border" width="200"> 
                        </td>                                   
                    </tr>    
                </table>
            </div>
        </div>
    </div> 
</div>