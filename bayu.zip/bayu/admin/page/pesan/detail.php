<?php 
$id_pesan = $_GET['id_pesan'];
$ambil = $con->query("SELECT * FROM pesan NATURAL JOIN pelanggan WHERE id_pesan ='$_GET[id_pesan]'");
$pecah = $ambil->fetch_assoc();
$tgl = tgl_indo($pecah['tgl']);
$tgl1 = tgl_indo($pecah['tgl_pesan']);
?>

<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Detail Pesanan</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="index.php">Beranda</a></li>
                    <li class="breadcrumb-item">Data Pesanan</li>
                    <li class="breadcrumb-item active">Detail Pesanan</li>
                </ol>
            </div>

        </div>
    </div>
</div>


<div class="row"> 
    <div class="col-md-4"> </div>
    <div class="col-md-5"> 
        <div class="card">
            <div class="card-header bg-info">
                <div class="card-title">
                    <h5 class="text-white">Data Pelanggan</h5>
                </div>
            </div>
            <div class="card-body">  
                <table>
                    <tr>
                        <th>Nama</th>
                        <td>:</td>
                        <td><?php echo $pecah['nama_pelanggan'] ?></td>
                    </tr>
                    <tr>
                        <th>Telepon</th>
                        <td>:</td>
                        <td><?php echo $pecah['nohp_pelanggan'] ?></td>
                    </tr>
                    <tr>
                        <th>Email</th>
                        <td>:</td>
                        <td><?php echo $pecah['email_pelanggan'] ?></td>
                    </tr>
                    <tr>
                        <th>Alamat</th>
                        <td>:</td>
                        <td><?php echo $pecah['alamat_pelanggan'] ?></td>
                    </tr> 
                    <tr>
                        <th>&nbsp;</th>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                    </tr>
                </table>  
            </div> 
        </div> 
    </div>
    <div class="col-md-3"> 
        <div class="card">
            <div class="card-header bg-info">
                <div class="card-title">
                    <h5 class="text-white">Data Transaksi Pesanan</h5>
                </div>
            </div>
            <div class="card-body">  
                <table>
                    <tr>
                        <th>Faktur</th>
                        <td>:</td>
                        <td><?php echo $pecah['id_pesan'] ?></td>
                    </tr>
                    <tr>
                        <th>Tanggal</th>
                        <td>:</td>
                        <td><?php echo $tgl1 ?></td>
                    </tr>
                    <tr>
                        <th>Status</th>
                        <td>:</td>
                        <td>
                            <?php
                            if($pecah['sts_pesan'] == 'Pending'){ ?>
                            <span class="badge bg-warning"><?php echo $pecah['sts_pesan']; ?></span>
                            <?php } ?>
                            <?php
                            if($pecah['sts_pesan'] == 'Sudah Kirim Pembayaran'){ ?>
                            <span class="badge bg-success"><?php echo $pecah['sts_pesan']; ?></span>
                            <?php } ?>
                        </td>
                    </tr>  
                    <tr>
                        <th>&nbsp;</th>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                    </tr>
                    <tr>
                        <th>&nbsp;</th>
                        <td>&nbsp;</td>
                        <td>
                            <?php
                            if($pecah['sts_pesan'] == 'Sudah Kirim Pembayaran'){ ?>
                            <a href="?page=pesan&aksi=bayar&id_pesan=<?php echo $pecah['id_pesan'] ?>" title="Pembayaran" class="btn btn-info btn-sm"> Pembayaran</a> 
                            <?php } ?>
                        </td>
                    </tr>
                </table>  
            </div> 
        </div> 
    </div>
    <div class="col-md-12">
        <div class="card">
            <div class="card-header bg-info">
                <div class="card-title">
                    <h5 class="text-white">Menu Yang Dipesan</h5>
                </div>
            </div>

            <form class="needs-validation" novalidate method="POST" enctype="multipart/form-data"> <br>
                <div class="card">
                    <div class="card-body">   
                        <div class="row mb-3">
                            <table class="table table-bordered align-middle table-nowrap mb-0">
                                <thead class="thead-light">
                                    <tr>
                                        <th class="text-left"><b>No</b></th> 
                                        <th><b>Menu</b></th>  
                                        <th style="text-align: right;"><b>Harga</b></th>
                                        <th class="text-center"><b>Jumlah</b></th> 
                                        <th style="text-align: right;"><b>S.Total</b></th>  
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $no= 1;
                                        $sqltampil = mysqli_query($con, "SELECT * FROM pesan_detail
                                            NATURAL JOIN menu WHERE id_pesan='$id_pesan'");
                                        while ($data = mysqli_fetch_assoc($sqltampil)){
                                    ?>
                                    <tr>
                                        <td><?php echo $no++; ?></td> 
                                        <td class="text-left"><?php echo $data['nama_menu'] ?></td>  
                                        <td align="right"><?php echo number_format($data['harga'], 0, ',','.') ?></td>
                                        <td align="center"><?php echo $data['jumlah'] ?> /Porsi</td> 
                                        <td align="right"><?php echo number_format($data['subharga'], 0, ',','.') ?></td>
                                        <input type="text" value="<?php echo $data['id_pesan'] ?>" hidden name="id_pesan">  
                                    </tr> 
                                    <?php } ?>
                                </tbody>
                                <tr>
                                    <th colspan="4" style="text-align: right;"><b>SUB TOTAL</b></th>
                                    <td style="text-align: right;"><b><?php echo number_format($pecah['total_pesan'], 0, ',','.') ?></b></td>
                                </tr> 
                            </table>
                        </div>   
                    </div> 
                </div>
            </form> 
        </div>
    </div>
</div>  
<script type="text/javascript">
    function angka(evt) 
    {
        var charCode = (evt.which) ? evt.which : event.keyCode
        if (charCode > 31 && (charCode < 48 || charCode > 57)) 
        {
            return false;
        }
        return true;
    }
</script>


<script type="text/javascript">

    var total_b = document.getElementById('total_b');
    total_b.addEventListener('keyup', function(e)
    {
        total_b.value = formatRupiah(this.value);
    }); 
    
    /* Fungsi */
    function formatRupiah(angka, prefix)
    {
        var number_string = angka.replace(/[^,\d]/g, '').toString(),
            split    = number_string.split(','),
            sisa     = split[0].length % 3,
            rupiah     = split[0].substr(0, sisa),
            ribuan     = split[0].substr(sisa).match(/\d{3}/gi);
            
        if (ribuan) {
            separator = sisa ? '.' : '';
            rupiah += separator + ribuan.join('.');
        }
        
        rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
        return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
    }

    function hitung()
    {
        //tunjangan
        var total_b = document.getElementById('total_b').value;  

        if(total_b=="")
        {
            var total_b = 0;
        }else{
            var total_b = parseInt(total_b.split(".").join(""));
        }  
    
    }

</script>  