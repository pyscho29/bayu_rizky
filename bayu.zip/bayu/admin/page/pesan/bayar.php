<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Konfirmasi Pembayaran Pesanan</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="index.php">Beranda</a></li>
                    <li class="breadcrumb-item">Data Pesanan</li>
                    <li class="breadcrumb-item active">Konfirmasi Pembayaran Pesanan</li>
                </ol>
            </div>

        </div>
    </div>
</div>


<div class="row"> 
    <div class="col-md-6"> 
        <div class="card">
            <div class="card-header bg-info">
                <div class="card-title">
                    <h5 class="text-white">Data Pembayaran</h5>
                </div>
            </div>
            <div class="card-body">  
                <?php
                $id_pesan = $_GET['id_pesan'];
                $ambil = $con->query("SELECT * FROM bayar WHERE id_pesan='$id_pesan'");
                $detail = $ambil->fetch_assoc();
                ?>

                <form method="post" enctype="multipart/form-data">

                    <table class="table display table-bordered table-striped table-hover basic">
                        <tr>
                            <th>Penyetor</th>
                            <td><?php echo $detail['penyetor'] ?></td>
                        </tr>
                        <tr>
                            <th>Bank</th>
                            <td><?php echo $detail['bank'] ?></td>
                        </tr>
                        <tr>
                            <th>Jumlah</th>
                            <td>Rp. <?php echo number_format($detail['jml'], 0, ',','.') ?>,-</td>
                        </tr>
                        <tr>
                            <th>Tanggal</th>
                            <td><?php echo $detail['tgl'] ?></td>
                        </tr>
                        <tr>
                            <th>Status</th>
                            <td>
                                <input class="form-control" type="text" name="sts_pesan" placeholder="Proses atau Selesai" required>
                            </td>
                        </tr>
                        <tr>
                            <th>&nbsp;</th>
                            <th>
                                <button name="proses" class="btn btn-sm btn-info">Update Data</button>
                                <a href="?page=pesan" class="btn btn-danger btn-sm"> Kembali</a>
                            </th>
                        </tr>
                    </table> 

                <?php 
                if (isset($_POST['proses'])) 
                {
                    $sts_pesan   = $_POST['sts_pesan'];
                    $con->query("UPDATE pesan SET sts_pesan='$sts_pesan' WHERE id_pesan='$id_pesan' ");

                    echo "<script>alert('Data pemesanan berhasil diupdate.');</script>";
                    echo "<script>location='?page=pesan';</script>";
                }
                ?>
            </div> 
        </div> 
    </div>
    <div class="col-md-6"> 
        <div class="card">
            <div class="card-header bg-info">
                <div class="card-title">
                    <h5 class="text-white">Bukti Transfer Pembayaran Pesanan</h5>
                </div>
            </div>
            <div class="card-body">  
                <center>
                    <div class="row gallery-wrapper">
                        <div class="element-item">
                            <div class="gallery-box card">
                                <div class="gallery-container">
                                    <img src="../scss/bukti_bayar/<?php echo $detail['bukti'] ?>" alt="" class="image-popup img-responsive img-thumbnail">  
                                </div>
                            </div>
                        </div> 
                    </div>
                </center> 
            </div> 
        </div> 
    </div>
</div>   