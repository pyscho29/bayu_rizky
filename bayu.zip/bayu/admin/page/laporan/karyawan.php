<?php
    error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
    include "../../inc/koneksi.php";
    include "../../inc/tanggal.php";  
?> 

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
        <link rel="shortcut icon" href="../../assets/<?php echo $logo ?>">  
        <title><?php echo $judul ?></title>
        <link rel="stylesheet" href="paper.css">
        <style>
            @page { size: A4 }
          
            h4 {
                font-weight: bold;
                font-size: 13pt;
                text-align: center;
            }
          
            table {
                border-collapse: collapse;
                width: 100%;
            }
          
            .table th {
                padding: 8px 3px;
                border:1px solid #000000;
                text-align: center;
            }
          
            .table td {
                padding: 3px 3px;
                border:1px solid #000000;
            }
          
            .text-center {
                text-align: center;
            }

            .horizontal_center {
                border-top: 3px solid black;
                height: 2px;
                line-height: 30px; 
            }

            .kanan{
                float: right;
            }
        </style> 
    </head>  
    <body class="A4">
        <section class="sheet padding-10mm">
            <table width="100%" class="table"> 
                <tbody>
                    <tr>
                        <td style="vertical-align: middle; text-align: center;">
                            <a href="#">
                                <img src="../../assets/<?php echo $logo ?>" width="70">
                            </a>
                        </td>
                        <td style="text-align: center;">
                            <strong><?php echo $judul ?></strong> <br>
                            <strong>BANJARMASIN</strong> <br>
                            <small><?php echo $alamat ?></small> <br>
                            <small>Telepon : <?php echo $telp ?> / Email : <?php echo $email ?></small>
                        </td>
                    </tr> 
                </tbody>
            </table>
            <div class="horizontal_center"></div>

            <h4>LAPORAN KARYAWAN</h4> 
      
            <table class="table">
                <thead>
                    <tr>
                        <th style="font-size: 12px; text-align: center;" width="5%">No</th>
                        <th style="font-size: 12px; text-align: left;">Nama</th>
                        <th style="font-size: 12px; text-align: left;">Tempat, Tanggal Lahir</th>
                        <th style="font-size: 12px; text-align: left;">Telepon</th>
                        <th style="font-size: 12px; text-align: left;">Alamat</th> 
                    </tr> 
                </thead> 
                <tbody>
                    <?php $nomor=1; ?>
                    <?php $ambil=$con->query("SELECT * FROM karyawan ORDER BY id_karyawan DESC"); ?>
                    <?php while ($pecah = $ambil->fetch_assoc()) { 
                        $tgl = tgl_indo($pecah['tgl_lahir']); ?>
                    <tr>
                        <td style="font-size: 12px; text-align: center;"><?php echo $nomor; ?>.</td>
                        <td style="font-size: 12px;"><?php echo $pecah['nama_karyawan']; ?></td>   
                        <td style="font-size: 12px;"><?php echo $pecah['tmp_lahir']; ?>, <?php echo $tgl; ?></td>   
                        <td style="font-size: 12px;"><?php echo $pecah['nohp_karyawan']; ?></td>   
                        <td style="font-size: 12px;"><?php echo $pecah['alamat_karyawan']; ?></td>    
                    </tr>
                    <?php $nomor++; ?>
                    <?php } ?>
                </tbody>
            </table> <br>

            <table align="center">
                <tr>
                    <td style="font-size: 12px">Banjarmasin, <?php echo tgl_indo(date('Y-m-d')); ?> <br> PIMPINAN</td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                </tr> 
                <tr>
                    <td style="font-size: 12px"><b><?php echo $pimpinan ?></b></td>
                </tr> 
            </table>
        </section>
    </body>
</html> 
<script type="text/javascript">window.print();</script>