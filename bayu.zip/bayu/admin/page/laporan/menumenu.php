<?php
    error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
    include "../../inc/koneksi.php";
    include "../../inc/tanggal.php"; 
    $tgl_awal = $_POST['tgl_awal'];
    $tgl_akhir =$_POST['tgl_akhir'];
    $tgl1 = tgl_indo($tgl_awal);
    $tgl2 = tgl_indo($tgl_akhir);
    $cari = mysqli_query ($con, "SELECT * pesan WHERE tgl_pesan BETWEEN '$tgl_awal' AND '$tgl_akhir'"); 
?> 

<?php 
$bulan = $_POST['bulan'];  
$tahun = $_POST['tahun'];
$kiau=$con->query("SELECT tgl_pesan,nama_menu, SUM(jumlah) jumlah FROM pesan_detail NATURAL JOIN pesan NATURAL JOIN menu  WHERE month(tgl_pesan)='$bulan' AND year(tgl_pesan)='$tahun' GROUP BY nama_menu ORDER BY jumlah DESC LIMIT 10;"); ?>
<?php $dapat = $kiau->fetch_assoc();
    $bln1 = getBulan($bulan); ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
        <link rel="shortcut icon" href="../../assets/<?php echo $logo ?>">  
        <title><?php echo $judul ?></title>
        <link rel="stylesheet" href="paper.css">
        <style>
            @page { size: A4 }
          
            h4 {
                font-weight: bold;
                font-size: 13pt;
                text-align: center;
            }
          
            table {
                border-collapse: collapse;
                width: 100%;
            }
          
            .table th {
                padding: 8px 3px;
                border:1px solid #000000;
                text-align: center;
            }
          
            .table td {
                padding: 3px 3px;
                border:1px solid #000000;
            }
          
            .text-center {
                text-align: center;
            }

            .horizontal_center {
                border-top: 3px solid black;
                height: 2px;
                line-height: 30px; 
            }

            .kanan{
                float: right;
            }
        </style> 
    </head>  
    <body class="A4">
        <section class="sheet padding-10mm">
            <table width="100%" class="table"> 
                <tbody>
                    <tr>
                        <td style="vertical-align: middle; text-align: center;">
                            <a href="#">
                                <img src="../../assets/<?php echo $logo ?>" width="70">
                            </a>
                        </td>
                        <td style="text-align: center;">
                            <strong><?php echo $judul ?></strong> <br>
                            <strong>BANJARMASIN</strong> <br>
                            <small><?php echo $alamat ?></small> <br>
                            <small>Telepon : <?php echo $telp ?> / Email : <?php echo $email ?></small>
                        </td>
                    </tr> 
                </tbody>
            </table>
            <div class="horizontal_center"></div>

            <h4>LAPORAN MENU TERLARIS <br> <small style="font-size: 11px;">Periode : <?php echo $bln1 ?> - <?php echo $tahun ?> </small></h4> 
      
            <table class="table">
                <thead>
                    <tr>
                        <th style="font-size: 12px; vertical-align: middle; color: black;" align="center" width="5%">No</th>
                        <th style="font-size: 12px; vertical-align: middle; color: black;" align="left">Nama</th>
                        <th style="font-size: 12px; vertical-align: middle; color: black;" align="center" width="10%">Jumlah Terjual</th> 
                    </tr> 
                </thead> 
                <tbody>
                    <?php $nomor=1; ?>
                    <?php 
                    $bulan = $_POST['bulan'];  
                    $tahun = $_POST['tahun'];
                    $ambil=$con->query("SELECT sts_pesan,nama_menu, SUM(jumlah) jumlah FROM pesan_detail NATURAL JOIN pesan NATURAL JOIN menu WHERE month(tgl_pesan)='$bulan' AND year(tgl_pesan)='$tahun' AND sts_pesan='Selesai' OR sts_pesan='Sudah Kirim Pembayaran' OR sts_pesan='Proses' GROUP BY nama_menu ORDER BY jumlah DESC LIMIT 8;"); ?>
                    <?php while ($pecah = $ambil->fetch_assoc()) { ?>
                    <tr>
                        <td style="font-size: 12px;" align="center"><?php echo $nomor; ?></td> 
                        <td style="font-size: 12px;"><?php echo $pecah['nama_menu']; ?></td>
                        <td style="font-size: 12px;" align="center"><?php echo $pecah['jumlah']; ?></td> 
                    </tr>
                    <?php $nomor++; ?>
                    <?php } ?>
                </tbody> 
            </table> <br>

            <table align="center">
                <tr>
                    <td style="font-size: 12px">Banjarmasin, <?php echo tgl_indo(date('Y-m-d')); ?> <br> PIMPINAN</td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                </tr> 
                <tr>
                    <td style="font-size: 12px"><b><?php echo $pimpinan ?></b></td>
                </tr> 
            </table>
        </section>
    </body>
</html> 
<script type="text/javascript">window.print();</script>