<!-- Januari -->
<?php $ambil=$con->query("SELECT *  FROM pesan NATURAL JOIN pelanggan WHERE month(tgl_pesan)='01' AND year(tgl_pesan)='$tahun' ORDER BY id_pesan DESC"); ?>
<?php while ($pecah = $ambil->fetch_assoc()) { 
    $tgl = tgl_indo($pecah['tgl_pesan']);
    $ttl5 = $pecah['total_pesan']; 
    $ttl_jan = $ttl5 + $ttl_jan;  
?> 
<?php } ?> 

<!-- Februari -->
<?php $ambil=$con->query("SELECT *  FROM pesan NATURAL JOIN pelanggan WHERE month(tgl_pesan)='02' AND year(tgl_pesan)='$tahun' ORDER BY id_pesan DESC"); ?>
<?php while ($pecah = $ambil->fetch_assoc()) { 
    $tgl = tgl_indo($pecah['tgl_pesan']);
    $ttl5 = $pecah['total_pesan']; 
    $ttl_feb = $ttl5 + $ttl_feb;  
?> 
<?php } ?> 

<!-- Maret -->
<?php $ambil=$con->query("SELECT *  FROM pesan NATURAL JOIN pelanggan WHERE month(tgl_pesan)='03' AND year(tgl_pesan)='$tahun' ORDER BY id_pesan DESC"); ?>
<?php while ($pecah = $ambil->fetch_assoc()) { 
    $tgl = tgl_indo($pecah['tgl_pesan']);
    $ttl5 = $pecah['total_pesan']; 
    $ttl_mar = $ttl5 + $ttl_mar;  
?> 
<?php } ?> 

<!-- April -->
<?php $ambil=$con->query("SELECT *  FROM pesan NATURAL JOIN pelanggan WHERE month(tgl_pesan)='04' AND year(tgl_pesan)='$tahun' ORDER BY id_pesan DESC"); ?>
<?php while ($pecah = $ambil->fetch_assoc()) { 
    $tgl = tgl_indo($pecah['tgl_pesan']);
    $ttl5 = $pecah['total_pesan']; 
    $ttl_apr = $ttl5 + $ttl_apr;  
?> 
<?php } ?> 

<!-- Mei -->
<?php $ambil=$con->query("SELECT *  FROM pesan NATURAL JOIN pelanggan WHERE month(tgl_pesan)='05' AND year(tgl_pesan)='$tahun' ORDER BY id_pesan DESC"); ?>
<?php while ($pecah = $ambil->fetch_assoc()) { 
    $tgl = tgl_indo($pecah['tgl_pesan']);
    $ttl5 = $pecah['total_pesan']; 
    $ttl_mei = $ttl5 + $ttl_mei;  
?> 
<?php } ?> 

<!-- Juni -->
<?php $ambil=$con->query("SELECT *  FROM pesan NATURAL JOIN pelanggan WHERE month(tgl_pesan)='06' AND year(tgl_pesan)='$tahun' ORDER BY id_pesan DESC"); ?>
<?php while ($pecah = $ambil->fetch_assoc()) { 
    $tgl = tgl_indo($pecah['tgl_pesan']);
    $ttl5 = $pecah['total_pesan']; 
    $ttl_jun = $ttl5 + $ttl_jun;  
?> 
<?php } ?> 

<!-- Juli -->
<?php $ambil=$con->query("SELECT *  FROM pesan NATURAL JOIN pelanggan WHERE month(tgl_pesan)='07' AND year(tgl_pesan)='$tahun' ORDER BY id_pesan DESC"); ?>
<?php while ($pecah = $ambil->fetch_assoc()) { 
    $tgl = tgl_indo($pecah['tgl_pesan']);
    $ttl5 = $pecah['total_pesan']; 
    $ttl_jul = $ttl5 + $ttl_jul;  
?> 
<?php } ?> 

<!-- Agustus -->
<?php $ambil=$con->query("SELECT *  FROM pesan NATURAL JOIN pelanggan WHERE month(tgl_pesan)='08' AND year(tgl_pesan)='$tahun' ORDER BY id_pesan DESC"); ?>
<?php while ($pecah = $ambil->fetch_assoc()) { 
    $tgl = tgl_indo($pecah['tgl_pesan']);
    $ttl5 = $pecah['total_pesan']; 
    $ttl_feb = $ttl5 + $ttl_feb;  
?> 
<?php } ?> 

<!-- September -->
<?php $ambil=$con->query("SELECT *  FROM pesan NATURAL JOIN pelanggan WHERE month(tgl_pesan)='09' AND year(tgl_pesan)='$tahun' ORDER BY id_pesan DESC"); ?>
<?php while ($pecah = $ambil->fetch_assoc()) { 
    $tgl = tgl_indo($pecah['tgl_pesan']);
    $ttl5 = $pecah['total_pesan']; 
    $ttl_sep = $ttl5 + $ttl_sep;  
?> 
<?php } ?> 

<!-- Oktober -->
<?php $ambil=$con->query("SELECT *  FROM pesan NATURAL JOIN pelanggan WHERE month(tgl_pesan)='10' AND year(tgl_pesan)='$tahun' ORDER BY id_pesan DESC"); ?>
<?php while ($pecah = $ambil->fetch_assoc()) { 
    $tgl = tgl_indo($pecah['tgl_pesan']);
    $ttl5 = $pecah['total_pesan']; 
    $ttl_okt = $ttl5 + $ttl_okt;  
?> 
<?php } ?> 

<!-- November -->
<?php $ambil=$con->query("SELECT *  FROM pesan NATURAL JOIN pelanggan WHERE month(tgl_pesan)='11' AND year(tgl_pesan)='$tahun' ORDER BY id_pesan DESC"); ?>
<?php while ($pecah = $ambil->fetch_assoc()) { 
    $tgl = tgl_indo($pecah['tgl_pesan']);
    $ttl5 = $pecah['total_pesan']; 
    $ttl_nov = $ttl5 + $ttl_nov;  
?> 
<?php } ?> 

<!-- Desemnber -->
<?php $ambil=$con->query("SELECT *  FROM pesan NATURAL JOIN pelanggan WHERE month(tgl_pesan)='12' AND year(tgl_pesan)='$tahun' ORDER BY id_pesan DESC"); ?>
<?php while ($pecah = $ambil->fetch_assoc()) { 
    $tgl = tgl_indo($pecah['tgl_pesan']);
    $ttl5 = $pecah['total_pesan']; 
    $ttl_des = $ttl5 + $ttl_des;  
?> 
<?php } ?> 


<!-- Total -->
<?php $ambil=$con->query("SELECT *  FROM pesan NATURAL JOIN pelanggan WHERE year(tgl_pesan)='$tahun' ORDER BY id_pesan DESC"); ?>
<?php while ($pecah = $ambil->fetch_assoc()) { 
    $tgl = tgl_indo($pecah['tgl_pesan']);
    $ttl5 = $pecah['total_pesan']; 
    $total = $ttl_jan + $ttl_feb + $ttl_mar + $ttl_apr + $ttl_mei + $ttl_jun + $ttl_jul + $ttl_ags + $ttl_sep + $ttl_okt + $ttl_nov + $ttl_des;
    $bilangtotal = terbilang($total);   
?> 
<?php } ?> 