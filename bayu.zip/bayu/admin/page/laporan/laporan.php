<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Laporan</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="index.php">Beranda</a></li>
                    <li class="breadcrumb-item active">Laporan</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Data Laporan</h5>
            </div>
            <div class="card-body">
                <div class="live-preview">
                    <div class="row align-items-center g-3"> 
                        <div class="col-xxl-4">
                            <div class="row">
                                <label class="col-sm-3 col-form-label">Laporan Karyawan</label>
                                <div class="col-sm-9">
                                    <a href="page/laporan/karyawan.php" target="_blank" class="btn btn-success text-white"> Rekap Data</a>
                                </div>
                            </div> 
                            <br>
                            <div class="row">
                                <label class="col-sm-3 col-form-label">Laporan Menu Catering</label>
                                <div class="col-sm-9">
                                    <a href="page/laporan/menu.php" target="_blank" class="btn btn-success text-white"> Rekap Data</a>
                                </div>
                            </div>
                            <br>
                            <div class="row">
                                <label class="col-sm-3 col-form-label">Laporan Pelanggan</label>
                                <div class="col-sm-9">
                                    <a href="page/laporan/pelanggan.php" target="_blank" class="btn btn-success text-white"> Rekap Data</a>
                                </div>
                            </div>
                            <br>
                            <form method="post" action="page/laporan/pesan_periode.php" target="_blank"> 
                                <div class="row">
                                    <label class="col-sm-3 col-form-label">Laporan Pesanan Periode</label>
                                    <div class="col-sm-3">
                                        <div class="input-group">
                                            <span class="input-group-text">T.Awal</span>
                                            <input type="date" class="form-control" name="tgl_awal" required>
                                        </div> 
                                    </div>
                                    <div class="col-sm-3">
                                        <div class="input-group">
                                            <span class="input-group-text">T.Akhir</span>
                                            <input type="date" class="form-control" name="tgl_akhir" required>
                                        </div> 
                                    </div>
                                    <div class="col-sm-3">
                                        <button type="submit" class="btn btn-success">Cetak</button>
                                    </div>
                                </div>
                            </form>
                            <br>
 
                            <form method="post" action="page/laporan/menumenu.php" target="_blank"> 
                                <div class="row">
                                    <label class="col-sm-3 col-form-label">Laporan Menu Terjual Per Hari</label>
                                    <div class="col-sm-3">
                                        <div class="input-group">
                                            <span class="input-group-text">T.Awal</span>
                                            <input type="date" class="form-control" name="tgl_awal" required>
                                        </div> 
                                    </div>
                                    <div class="col-sm-3">
                                        <div class="input-group">
                                            <span class="input-group-text">T.Akhir</span>
                                            <input type="date" class="form-control" name="tgl_akhir" required>
                                        </div> 
                                    </div>
                                    <div class="col-sm-3">
                                        <button type="submit" class="btn btn-success">Cetak</button>
                                    </div>
                                </div>
                            </form>
                            <br>
                            <form method="post" action="page/laporan/pendapatan.php" target="_blank"> 
                                <div class="row">
                                    <label class="col-sm-3 col-form-label">Laporan Pendapatan</label> 
                                    <div class="col-sm-3">
                                        <div class="input-group">
                                            <span class="input-group-text">Tahun</span>
                                            <select class="form-control select2" name="tahun" required>
                                                <option></option>
                                                <?php
                                                $mulai = date('Y') - 6;
                                                for ($i= $mulai;$i<$mulai + 100;$i++){
                                                    $sel = $i == date('Y') ? ' selected = "selected"' : '';
                                                     echo '<option value="'.$i.'"'.$sel.'>'.$i.'</option>';
                                                }
                                                ?>
                                            </select>
                                        </div> 
                                    </div>
                                    <div class="col-sm-3">
                                        <button type="submit" class="btn btn-success">Cetak</button>
                                    </div>
                                </div>
                            </form>
                            <br>
                            <form method="post" action="page/laporan/pengeluaran.php" target="_blank"> 
                                <div class="row">
                                    <label class="col-sm-3 col-form-label">Laporan Pengeluaran</label> 
                                    <div class="col-sm-3">
                                        <div class="input-group">
                                            <span class="input-group-text">Bulan</span>
                                            <select class="form-control" name="bulan" required>
                                                <option>Pilih</option>
                                                <option value='01'>Januari</option>
                                                <option value='02'>Februari</option>
                                                <option value='03'>Maret</option>
                                                <option value='04'>April</option>
                                                <option value='05'>Mei</option>
                                                <option value='06'>Juni</option>
                                                <option value='07'>Juli</option>
                                                <option value='08'>Agustus</option>
                                                <option value='09'>September</option>
                                                <option value='10'>Oktober</option>
                                                <option value='11'>November</option>
                                                <option value='12'>Desember</option>
                                            </select>
                                        </div> 
                                    </div>
                                    <div class="col-sm-3">
                                        <div class="input-group">
                                            <span class="input-group-text">Tahun</span>
                                            <select class="form-control select2" name="tahun" required>
                                                <option></option>
                                                <?php
                                                $mulai = date('Y') - 6;
                                                for ($i= $mulai;$i<$mulai + 100;$i++){
                                                    $sel = $i == date('Y') ? ' selected = "selected"' : '';
                                                     echo '<option value="'.$i.'"'.$sel.'>'.$i.'</option>';
                                                }
                                                ?>
                                            </select>
                                        </div> 
                                    </div>
                                    <div class="col-sm-3">
                                        <button type="submit" class="btn btn-success">Cetak</button>
                                    </div>
                                </div>
                            </form>
                            <br>
                            <form method="post" action="page/laporan/menu_laris.php" target="_blank"> 
                                <div class="row">
                                    <label class="col-sm-3 col-form-label">Laporan Menu Terlaris</label> 
                                    <div class="col-sm-3">
                                        <div class="input-group">
                                            <span class="input-group-text">Bulan</span>
                                            <select class="form-control" name="bulan" required>
                                                <option>Pilih</option>
                                                <option value='01'>Januari</option>
                                                <option value='02'>Februari</option>
                                                <option value='03'>Maret</option>
                                                <option value='04'>April</option>
                                                <option value='05'>Mei</option>
                                                <option value='06'>Juni</option>
                                                <option value='07'>Juli</option>
                                                <option value='08'>Agustus</option>
                                                <option value='09'>September</option>
                                                <option value='10'>Oktober</option>
                                                <option value='11'>November</option>
                                                <option value='12'>Desember</option>
                                            </select>
                                        </div> 
                                    </div>
                                    <div class="col-sm-3">
                                        <div class="input-group">
                                            <span class="input-group-text">Tahun</span>
                                            <select class="form-control select2" name="tahun" required>
                                                <option></option>
                                                <?php
                                                $mulai = date('Y') - 6;
                                                for ($i= $mulai;$i<$mulai + 100;$i++){
                                                    $sel = $i == date('Y') ? ' selected = "selected"' : '';
                                                     echo '<option value="'.$i.'"'.$sel.'>'.$i.'</option>';
                                                }
                                                ?>
                                            </select>
                                        </div> 
                                    </div>
                                    <div class="col-sm-3">
                                        <button type="submit" class="btn btn-success">Cetak</button>
                                    </div>
                                </div>
                            </form>
                            <br>
                            <form method="post" action="page/laporan/riwayat.php" target="_blank"> 
                                <div class="row">
                                    <label class="col-sm-3 col-form-label">Laporan Riwayat Pesanan</label> 
                                    <div class="col-sm-6">
                                        <div class="input-group">
                                            <span class="input-group-text">Pelanggan</span>
                                            <select class="form-control" name="nama_pelanggan" required>
                                                <option>Pilih</option>
                                                <?php
                                                $sql=mysqli_query($con, "SELECT * FROM pelanggan");
                                                while ($pang=mysqli_fetch_array($sql))
                                                {
                                                    echo "<option value='$pang[nama_pelanggan]'>$pang[nama_pelanggan]</option>";
                                                }
                                                ?>
                                            </select>
                                        </div> 
                                    </div>
                                    <div class="col-sm-3">
                                        <button type="submit" class="btn btn-success">Cetak</button>
                                    </div>
                                </div>
                            </form>
                            <br>
                            <div class="row">
                                <label class="col-sm-3 col-form-label">Laporan Grafik Pendapatan</label>
                                <div class="col-sm-9">
                                    <a href="page/laporan/grafik_pendapatan.php" target="_blank" class="btn btn-success text-white"> Cetak</a>
                                </div>
                            </div>
                            <br>
                            <div class="row">
                                <label class="col-sm-3 col-form-label">Laporan Grafik Menu Terjual</label>
                                <div class="col-sm-9">
                                    <a href="page/laporan/grafik_menu.php" target="_blank" class="btn btn-success text-white"> Cetak</a>
                                </div>
                            </div>
                        </div> 
                    </div>
                </div>
            </div>
        </div>
    </div> 
</div>