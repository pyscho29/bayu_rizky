<?php
    error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
    include "../../inc/koneksi.php";
    include "../../inc/tanggal.php"; 
    $tgl_awal = $_POST['tgl_awal'];
    $tgl_akhir =$_POST['tgl_akhir'];
    $tgl1 = tgl_indo($tgl_awal);
    $tgl2 = tgl_indo($tgl_akhir);
    $cari = mysqli_query ($con, "SELECT * pesan WHERE tgl_pesan BETWEEN '$tgl_awal' AND '$tgl_akhir'"); 
?> 

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
        <link rel="shortcut icon" href="../../assets/<?php echo $logo ?>">  
        <title><?php echo $judul ?></title>
        <link rel="stylesheet" href="paper.css">
        <style>
            @page { size: A4 }
          
            h4 {
                font-weight: bold;
                font-size: 13pt;
                text-align: center;
            }
          
            table {
                border-collapse: collapse;
                width: 100%;
            }
          
            .table th {
                padding: 8px 3px;
                border:1px solid #000000;
                text-align: center;
            }
          
            .table td {
                padding: 3px 3px;
                border:1px solid #000000;
            }
          
            .text-center {
                text-align: center;
            }

            .horizontal_center {
                border-top: 3px solid black;
                height: 2px;
                line-height: 30px; 
            }

            .kanan{
                float: right;
            }
        </style> 
    </head>  
    <body class="A4">
        <section class="sheet padding-10mm">
            <table width="100%" class="table"> 
                <tbody>
                    <tr>
                        <td style="vertical-align: middle; text-align: center;">
                            <a href="#">
                                <img src="../../assets/<?php echo $logo ?>" width="70">
                            </a>
                        </td>
                        <td style="text-align: center;">
                            <strong><?php echo $judul ?></strong> <br>
                            <strong>BANJARMASIN</strong> <br>
                            <small><?php echo $alamat ?></small> <br>
                            <small>Telepon : <?php echo $telp ?> / Email : <?php echo $email ?></small>
                        </td>
                    </tr> 
                </tbody>
            </table>
            <div class="horizontal_center"></div>

            <h4>LAPORAN PESANAN <br> <small style="font-size: 11px;">Berdasarkan Periode Dari <?php echo $tgl1 ?> - Sampai <?php echo $tgl2 ?></small></h4> 
      
            <table class="table">
                <thead>
                    <tr>
                        <th style="font-size: 12px; text-align: center;" width="5%">No</th>
                        <th style="font-size: 12px; text-align: left;">Nota</th>
                        <th style="font-size: 12px; text-align: left;">Menu</th>
                        <th style="font-size: 12px; text-align: right;">Harga</th>
                        <th style="font-size: 12px; text-align: center;">Jumlah</th> 
                        <th style="font-size: 12px; text-align: right;">Sub Total</th> 
                        <th style="font-size: 12px; text-align: right;">Grand Total</th> 
                    </tr> 
                </thead> 
                <tbody>
                    <?php $nomor=1; ?>
                    <?php $ambil=$con->query("SELECT * FROM pesan NATURAL JOIN pelanggan ORDER BY id_pesan DESC"); ?>
                    <?php while ($pecah = $ambil->fetch_assoc()) { 
                        $tgl = tgl_indo($pecah['tgl_pesan']); ?>
                    <tr>
                        <td style="font-size: 12px; text-align: center;"><?php echo $nomor; ?>.</td>
                        <td style="font-size: 12px;">
                            Nota : <?php echo $pecah['id_pesan']; ?> <br>
                            <?php echo $pecah['nama_pelanggan']; ?> <br>
                            <?php echo $tgl; ?>
                        </td>   
                        <td style="font-size: 12px;">
                            <?php 
                            $sql_barang = mysqli_query($con, "SELECT * FROM pesan_detail WHERE id_pesan = '$pecah[id_pesan]'");
                            while ($data_barang = mysqli_fetch_array($sql_barang))
                            {
                                echo $data_barang['nama_menu']."<br>";
                            } 
                            ?>
                        </td>    
                        <td style="font-size: 12px; text-align: right;">
                            <?php 
                            $sql_barang = mysqli_query($con, "SELECT * FROM pesan_detail WHERE id_pesan = '$pecah[id_pesan]'");
                            while ($data_barang = mysqli_fetch_array($sql_barang))
                            {
                                echo number_format($data_barang['hmenu'], 0, ',','.')."<br>";
                            } 
                            ?>
                        </td>    
                        <td style="font-size: 12px; text-align: center;">
                            <?php 
                            $sql_barang = mysqli_query($con, "SELECT * FROM pesan_detail WHERE id_pesan = '$pecah[id_pesan]'");
                            while ($data_barang = mysqli_fetch_array($sql_barang))
                            {
                                echo $data_barang['jumlah']." /Porsi <br>";
                            } 
                            ?>
                        </td>
                        <td style="font-size: 12px; text-align: right;">
                            <?php 
                            $sql_barang = mysqli_query($con, "SELECT * FROM pesan_detail WHERE id_pesan = '$pecah[id_pesan]'");
                            while ($data_barang = mysqli_fetch_array($sql_barang))
                            {
                                echo number_format($data_barang['subharga'], 0, ',','.')."<br>";
                            } 
                            ?>
                        </td>     
                        <td style="font-size: 12px; text-align: right;"><?php echo number_format($pecah['total_pesan'], 0, ',','.') ?></td> 
                    </tr>
                    <?php $nomor++; ?>
                    <?php } ?>
                </tbody>
            </table> <br>

            <table align="center">
                <tr>
                    <td style="font-size: 12px">Banjarmasin, <?php echo tgl_indo(date('Y-m-d')); ?> <br> PIMPINAN</td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                </tr> 
                <tr>
                    <td style="font-size: 12px"><b><?php echo $pimpinan ?></b></td>
                </tr> 
            </table>
        </section>
    </body>
</html> 
<script type="text/javascript">window.print();</script>