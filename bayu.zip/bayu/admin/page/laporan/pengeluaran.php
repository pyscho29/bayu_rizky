<?php
    error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
    include "../../inc/koneksi.php";
    include "../../inc/tanggal.php";  
    include "../../../terbilang.php";  
?> 

<?php   
$bulan = $_POST['bulan'];
$tahun = $_POST['tahun'];
$kiau=$con->query("SELECT * FROM pengeluaran WHERE bulan='$bulan' AND tahun='$tahun'"); ?>
<?php $dapat = $kiau->fetch_assoc();
$bln1 = getBulan($bulan); 
$ttl5 = $pecah['jkotor']; 
$ttl6 = $ttl5 + $ttl6; 
$bilang = terbilang($ttl6);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
        <link rel="shortcut icon" href="../../assets/<?php echo $logo ?>">  
        <title><?php echo $judul ?></title>
        <link rel="stylesheet" href="paper.css">
        <style>
            @page { size: A4 }
          
            h4 {
                font-weight: bold;
                font-size: 13pt;
                text-align: center;
            }
          
            table {
                border-collapse: collapse;
                width: 100%;
            }
          
            .table th {
                padding: 8px 3px;
                border:1px solid #000000;
                text-align: center;
            }
          
            .table td {
                padding: 3px 3px;
                border:1px solid #000000;
            }
          
            .text-center {
                text-align: center;
            }

            .horizontal_center {
                border-top: 3px solid black;
                height: 2px;
                line-height: 30px; 
            }

            .kanan{
                float: right;
            }
        </style> 
    </head>  
    <body class="A4">
        <section class="sheet padding-10mm">
            <table width="100%" class="table"> 
                <tbody>
                    <tr>
                        <td style="vertical-align: middle; text-align: center;">
                            <a href="#">
                                <img src="../../assets/<?php echo $logo ?>" width="70">
                            </a>
                        </td>
                        <td style="text-align: center;">
                            <strong><?php echo $judul ?></strong> <br>
                            <strong>BANJARMASIN</strong> <br>
                            <small><?php echo $alamat ?></small> <br>
                            <small>Telepon : <?php echo $telp ?> / Email : <?php echo $email ?></small>
                        </td>
                    </tr> 
                </tbody>
            </table>
            <div class="horizontal_center"></div>

            <h4>LAPORAN PENGELUARAN <br> <small style="font-size: 11px;">Periode : <?php echo $bln1 ?> - <?php echo $tahun ?></small></h4> 
      
            <table class="table">
                <thead>
                    <tr>
                        <th style="font-size: 12px; text-align: center;" width="5%">No</th> 
                        <th style="font-size: 12px; text-align: right;">Periode</th> 
                        <th style="font-size: 12px; text-align: right;">PLN</th> 
                        <th style="font-size: 12px; text-align: right;">PDAM</th> 
                        <th style="font-size: 12px; text-align: right;">Gaji</th> 
                        <th style="font-size: 12px; text-align: right;">Jumlah Kotor</th> 
                    </tr> 
                </thead> 
                <tbody>
                    <?php $nomor=1; ?>
                    <?php $ambil=$con->query("SELECT *  FROM pengeluaran WHERE bulan='$bulan' AND tahun='$tahun' ORDER BY id_pengeluaran DESC"); ?>
                    <?php while ($pecah = $ambil->fetch_assoc()) { 
                        $bln1 = getBulan($pecah['bulan']);  
                        $ttl5 = $pecah['jkotor']; 
                        $ttl6 = $ttl5 + $ttl6; 
                        $bilang = terbilang($ttl6);
                    ?>
                    <tr>
                        <td style="font-size: 12px; text-align: center;"><?php echo $nomor; ?>.</td> 
                        <td style="font-size: 12px; text-align: right;"><?php echo $bln1 ?> - <?php echo $pecah['tahun'] ?></td> 
                        <td style="font-size: 12px; text-align: right;"><?php echo number_format($pecah['pln'], 0, ',','.') ?></td> 
                        <td style="font-size: 12px; text-align: right;"><?php echo number_format($pecah['pdam'], 0, ',','.') ?></td> 
                        <td style="font-size: 12px; text-align: right;"><?php echo number_format($pecah['gaji'], 0, ',','.') ?></td> 
                        <td style="font-size: 12px; text-align: right;"><?php echo number_format($pecah['jkotor'], 0, ',','.') ?></td> 
                    </tr>
                    <?php $nomor++; ?>
                    <?php } ?>
                </tbody>
                <tfoot>
                    <tr bgcolor="white">
                        <th style="font-size: 14px; text-align: center;" colspan="5" rowspan="2">TOTAL</th>
                        <th style="font-size: 14px; text-align: right;" rowspan="2">
                            Rp. <?php echo number_format($ttl6, 0, ',','.') ?> <br>
                            <small><u><?php echo $bilang ?> Rupiah</u></small>
                        </th>
                    </tr>
                </tfoot>
            </table> <br>

            <table align="center">
                <tr>
                    <td style="font-size: 12px">Banjarmasin, <?php echo tgl_indo(date('Y-m-d')); ?> <br> PIMPINAN</td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                </tr> 
                <tr>
                    <td style="font-size: 12px"><b><?php echo $pimpinan ?></b></td>
                </tr> 
            </table>
        </section>
    </body>
</html> 
<script type="text/javascript">window.print();</script>