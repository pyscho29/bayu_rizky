<?php
    error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
    include "../../inc/koneksi.php";
    include "../../inc/tanggal.php";  

    $label = ["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];
 
    for($bulan = 1;$bulan < 13;$bulan++)
    {
        $query = mysqli_query($con,"select sum(total_pesan) as total_pesan from pesan where MONTH(tgl_pesan)='$bulan'");
        $row = $query->fetch_array();
        $jumlah_produk[] = $row['total_pesan'];
    }
?>  

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
        <link rel="shortcut icon" href="../../assets/<?php echo $logo ?>">  
        <title><?php echo $judul ?></title>
        <link rel="stylesheet" href="paper.css">
        <style>
            @page { size: A4 }
          
            h4 {
                font-weight: bold;
                font-size: 13pt;
                text-align: center;
            }
          
            table {
                border-collapse: collapse;
                width: 100%;
            }
          
            .table th {
                padding: 8px 3px;
                border:1px solid #000000;
                text-align: center;
            }
          
            .table td {
                padding: 3px 3px;
                border:1px solid #000000;
            }
          
            .text-center {
                text-align: center;
            }

            .horizontal_center {
                border-top: 3px solid black;
                height: 2px;
                line-height: 30px; 
            }

            .kanan{
                float: right;
            }
        </style> 
    </head>  
    <body class="A4">
        <section class="sheet padding-10mm">
            <table width="100%" class="table"> 
                <tbody>
                    <tr>
                        <td style="vertical-align: middle; text-align: center;">
                            <a href="#">
                                <img src="../../assets/<?php echo $logo ?>" width="70">
                            </a>
                        </td>
                        <td style="text-align: center;">
                            <strong><?php echo $judul ?></strong> <br>
                            <strong>BANJARMASIN</strong> <br>
                            <small><?php echo $alamat ?></small> <br>
                            <small>Telepon : <?php echo $telp ?> / Email : <?php echo $email ?></small>
                        </td>
                    </tr> 
                </tbody>
            </table>
            <div class="horizontal_center"></div>

            <h4>LAPORAN GRAFIK PENDAPATAN</h4> 
      
            <table class="table">
                <p class="mb-0">
                    <canvas id="myChart"></canvas>
                </p>
            </table> <br>

            <table align="center">
                <tr>
                    <td style="font-size: 12px">Banjarmasin, <?php echo tgl_indo(date('Y-m-d')); ?> <br> PIMPINAN</td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                </tr> 
                <tr>
                    <td style="font-size: 12px"><b><?php echo $pimpinan ?></b></td>
                </tr> 
            </table>
        </section>

        <script src="../../Chart.js"></script>
        <script>
            var ctx = document.getElementById("myChart").getContext('2d');
            var myChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: <?php echo json_encode($label); ?>,
                    datasets: [{
                        label: 'Grafik Pendapatan',
                        data: <?php echo json_encode($jumlah_produk); ?>,
                        backgroundColor: '#405189',
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        yAxes: [{
                            ticks: {
                                beginAtZero:true
                            }
                        }]
                    }
                }
            });
        </script>

    </body>
</html> 
<script type="text/javascript">window.print();</script>