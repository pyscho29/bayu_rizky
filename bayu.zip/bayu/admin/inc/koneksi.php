<?php

	$con = mysqli_connect("localhost", "root", "", "db_catering");
	if (!$con){
		echo "Koneksi Ke Database Gagal";
	}  

?> 

<?php $ambil_set=$con->query("SELECT * FROM meta"); ?>
<?php 
$set = $ambil_set->fetch_assoc(); 
$judul = $set['judul_meta']; 
$alamat = $set['alamat_meta'];
$telp = $set['telp_meta'];
$email = $set['email_meta'];
$pimpinan = $set['nama_pimpinan'];
$logo = $set['logo_meta'];
$singkatan = $set['singkatan'];
?>