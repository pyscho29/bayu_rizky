<div class="app-menu navbar-menu"> 

    <div class="navbar-brand-box">
        <!-- Dark Logo-->
        <a href="index.php" class="logo logo-dark">
            <span class="logo-sm">
                <img src="assets/<?php echo $logo ?>" alt="" height="22">
            </span>
            <span class="logo-lg">
                <img src="assets/cariz.png" alt="" height="100" width="200px">
            </span>
        </a> 
        <a href="index.php" class="logo logo-light">
            <span class="logo-sm">
                <img src="assets/<?php echo $logo ?>" alt="" height="22">
            </span>
            <span class="logo-lg">
                <img src="assets/cariz.png" alt="" height="100" width="200px">
            </span>
        </a>
        <button type="button" class="btn btn-sm p-0 fs-20 header-item float-end btn-vertical-sm-hover" id="vertical-hover">
            <i class="ri-record-circle-line"></i>
        </button>
    </div>

    <div id="scrollbar">
        <div class="container-fluid">
            <div id="two-column-menu"></div>
            <ul class="navbar-nav" id="navbar-nav">

                <li class="menu-title"><span data-key="t-menu">Menu</span></li>
                <li class="nav-item">
                    <a class="nav-link menu-link" href="index.php">
                        <i class="ri-home-5-line"></i> <span data-key="t-dashboards">Beranda</span>
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link menu-link" href="#sidebarmaster" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarmaster">
                        <i class="ri-archive-drawer-line"></i> <span data-key="t-master">Data Master</span>
                    </a>
                    <div class="collapse menu-dropdown" id="sidebarmaster">
                        <ul class="nav nav-sm flex-column">
                            <li class="nav-item">
                                <a href="?page=admin" class="nav-link" data-key="t-admin"> Admin </a>
                            </li>
                            <li class="nav-item">
                                <a href="?page=karyawan" class="nav-link" data-key="t-karyawan"> Karyawan </a>
                            </li> 
                            <li class="nav-item">
                                <a href="?page=pelanggan" class="nav-link" data-key="t-pelanggan"> Pelanggan </a>
                            </li> 
                            <li class="nav-item">
                                <a href="?page=kategori" class="nav-link" data-key="t-kategori"> Kategori </a>
                            </li>  
                        </ul>
                    </div>
                </li> 

                <li class="nav-item">
                    <a class="nav-link menu-link" href="?page=menu">
                        <i class="ri-restaurant-line"></i> <span data-key="t-menu">Menu Catering</span>
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link menu-link" href="?page=pesan">
                        <i class="ri-shopping-bag-2-line"></i> <span data-key="t-pesanan">Pesanan</span>
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link menu-link" href="?page=riwayat">
                        <i class="ri-file-user-line"></i> <span data-key="t-riwayat">Riwayat Pesanan</span>
                    

                <li class="nav-item">
                    <a class="nav-link menu-link" href="?page=pengeluaran">
                        <i class="ri-currency-line"></i> <span data-key="t-pengeluaran">Pengeluaran</span>
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link menu-link" href="?page=setting">
                        <i class="ri-settings-5-line"></i> <span data-key="t-setting">Setting </span>
                    </a>
                </li>               

                <li class="nav-item">
                    <a class="nav-link menu-link" href="?page=laporan">
                        <i class="ri-printer-line"></i> <span data-key="t-laporan">Laporan</span>
                    </a>
                </li>

            </ul>
        </div>
    </div>

    <div class="sidebar-background"></div>
</div>