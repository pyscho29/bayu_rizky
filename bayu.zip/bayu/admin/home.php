<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Beranda</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0"> 
                    <li class="breadcrumb-item active">Beranda</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col">

        <div class="h-100">
            <div class="row mb-3 pb-1">
                <div class="col-12">
                    <div class="d-flex align-items-lg-center flex-lg-row flex-column">
                        <div class="flex-grow-1">
                            <h4 class="fs-16 mb-1">Selamat Datang, <?php echo $admin['nama_karyawan']; ?></h4>
                            <p class="text-muted mb-0">Here's what's happening with your store today.</p>
                        </div>
                        <div class="mt-3 mt-lg-0"></div>
                    </div><!-- end card header -->
                </div>
                <!--end col-->
            </div>
            <!--end row-->

            <div class="row">
                <div class="col-xl-6 col-md-6">
                    <!-- card -->
                    <div class="card card-animate">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <div class="flex-grow-1 overflow-hidden">
                                    <p class="text-uppercase fw-medium text-muted text-truncate mb-0"> Pendapatan </p>
                                </div>
                                <div class="flex-shrink-0">
                                    <h5 class="text-success fs-14 mb-0">
                                        <i class="ri-calendar-2-fill fs-13 align-middle"></i> <small><?php echo tgl_indo(date('Y-m-d')); ?></small>
                                    </h5>
                                </div>
                            </div>
                            <div class="d-flex align-items-end justify-content-between mt-4">
                                <div>
                                    <?php
                                    include 'inc/koneksi.php';
                                    $tgl1   = date("Y-m-d");
                                    $sql1   =  mysqli_query($con, "SELECT * FROM pesan WHERE tgl_pesan='$tgl1'");

                                    while($tampil1 = mysqli_fetch_assoc($sql1))
                                    {
                                        $total_pj =$total_pj+=$tampil1['total_pesan'];
                                    }
                                    ?>
                                    <h4 class="fs-22 fw-semibold ff-secondary mb-4">
                                        <span><?php echo number_format($total_pj, 0, ',','.'); ?>,-</span>
                                    </h4>
                                </div>
                                <div class="avatar-sm flex-shrink-0">
                                    <span class="avatar-title bg-soft-success rounded fs-3">
                                        <i class="bx bx-dollar-circle text-success"></i>
                                    </span>
                                </div>
                            </div>
                        </div><!-- end card body -->
                    </div><!-- end card -->
                </div><!-- end col -->

                <div class="col-xl-3 col-md-6">
                    <!-- card -->
                    <div class="card card-animate">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <div class="flex-grow-1 overflow-hidden">
                                 <p class="text-uppercase fw-medium text-muted text-truncate mb-0">Menu Catering</p>
                                </div>
                            </div>
                            <div class="d-flex align-items-end justify-content-between mt-4">
                                <?php 
                                $sql = mysqli_query($con,"SELECT * FROM menu"); 
                                $jum = mysqli_num_rows($sql);
                                ?>
                                <div>
                                    <h4 class="fs-22 fw-semibold ff-secondary mb-4">
                                        <span>Ada, <?php echo $jum ?></span>
                                    </h4>
                                </div>
                                <div class="avatar-sm flex-shrink-0">
                                    <span class="avatar-title bg-soft-info rounded fs-3">
                                        <i class="ri-restaurant-line text-info"></i>
                                    </span>
                                </div>
                            </div>
                        </div><!-- end card body -->
                    </div><!-- end card -->
                </div><!-- end col -->

                <div class="col-xl-3 col-md-6">
                    <!-- card -->
                    <div class="card card-animate">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <div class="flex-grow-1 overflow-hidden">
                                    <p class="text-uppercase fw-medium text-muted text-truncate mb-0">Pelanggan</p>
                                </div> 
                            </div>
                            <div class="d-flex align-items-end justify-content-between mt-4">
                                <?php 
                                $sql = mysqli_query($con,"SELECT * FROM pelanggan"); 
                                $jum = mysqli_num_rows($sql);
                                ?>
                                <div>
                                    <h4 class="fs-22 fw-semibold ff-secondary mb-4">
                                        <span>Ada, <?php echo $jum ?></span>
                                    </h4>
                                </div>
                                <div class="avatar-sm flex-shrink-0">
                                    <span class="avatar-title bg-soft-warning rounded fs-3">
                                        <i class=" ri-user-3-line text-warning"></i>
                                    </span>
                                </div>
                            </div>
                        </div><!-- end card body -->
                    </div><!-- end card -->
                </div><!-- end col --> 

            </div> <!-- end row-->

        </div> <!-- end .h-100-->

    </div> <!-- end col -->

    
</div>

<div class="row">
    <div class="col-xl-8">
        <div class="card">
            <div class="card-header align-items-center d-flex">
                <h4 class="card-title mb-0 flex-grow-1">Recent Orders <br> <small><code>Pending dan Sudah Kirim Pembayaran</code></small></h4> 
            </div><!-- end card header -->

            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered align-middle table-nowrap mb-0">
                        <thead class="text-muted table-light">
                            <tr>
                                <th scope="col">Order ID</th>
                                <th scope="col">Pelanggan</th>
                                <th scope="col">Tanggal</th>
                                <th scope="col" class="text-end">Total</th>
                                <th scope="col">Status</th>
                                <th scope="col">Bukti Transfer</th>
                                <th scope="col" class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $ambil=$con->query("SELECT * FROM pesan NATURAL JOIN pelanggan NATURAL JOIN bayar WHERE sts_pesan='Pending' OR sts_pesan='Sudah Kirim Pembayaran' ORDER BY id_pesan DESC"); ?>
                        <?php while ($pecah = $ambil->fetch_assoc()) { 
                        ?>
                        <tr>
                            <td><?php echo $pecah['id_pesan'] ?></td> 
                            <td><?php echo $pecah['nama_pelanggan'] ?></td> 
                            <td><?php echo $pecah['tgl_pesan'] ?></td> 
                            <td class="text-end"><?php echo number_format($pecah['total_pesan'], 0, ',','.') ?></td>
                            <td><?php echo $pecah['sts_pesan'] ?></td>
                            <td> 
                                <div class="row gallery-wrapper">
                                    <div class="element-item">
                                        <div class="gallery-box card">
                                            <div class="gallery-container">
                                                <a class="image-popup" href="../scss/bukti_bayar/<?php echo $pecah['bukti'] ?>" title="">
                                                    Lihat 
                                                </a>
                                            </div>
                                        </div>
                                    </div> 
                                </div>
                            </td>
                            <td class="text-center">
                                <a href="?page=pesan&aksi=detail&id_pesan=<?php echo $pecah['id_pesan'] ?>" target="blank" title="Detail Transaksi" class="btn btn-soft-secondary btn-sm"><i class="ri-file-list-3-line"></i></a> 
                            </td>
                        </tr>
                        <?php } ?>
                        </tbody><!-- end tbody -->
                    </table><!-- end table -->
                </div>
            </div>
        </div> <!-- .card-->
    </div> <!-- .col--> 
    
    <!-- 
    <div class="col-xxl-6">
        <h5 class="mb-3">Grafik</h5>
        <div class="card">
            <div class="card-body"> 
                <ul class="nav nav-tabs mb-3" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" data-bs-toggle="tab" href="#home" role="tab" aria-selected="false">
                            Pendapatan
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="tab" href="#product1" role="tab" aria-selected="false">
                            Menu Terjual
                        </a>
                    </li> 
                </ul> 
                <div class="tab-content  text-muted">
                    <div class="tab-pane active" id="home" role="tabpanel">
                        <h6>Graphic Pendapatan</h6>
                        <p class="mb-0">
                            <canvas id="myChart"></canvas>
                        </p>
                    </div>
                    <div class="tab-pane" id="product1" role="tabpanel">
                        <h6>Grafik Menu Terjual</h6>
                        <p class="mb-0">
                            <canvas id="myChart1"></canvas>
                        </p>
                    </div> 
                </div>
            </div> 
        </div> 
    </div>
     -->
     
</div>