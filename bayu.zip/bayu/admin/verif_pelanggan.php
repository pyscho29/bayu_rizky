<?php

    include "inc/koneksi.php";
    if(isset($_GET['id_pelanggan'])){

    $sql_ubah = "UPDATE pelanggan SET status_pelanggan='Aktif' WHERE id_pelanggan='".$_GET['id_pelanggan']."'";
    $query_ubah = mysqli_query($con, $sql_ubah);
    mysqli_close($con);

    if ($query_ubah) {
    
    ?>

    <script type="text/javascript">
        alert("Akun berhasil diverifikasi");
        window.location.href="index.php";
    </script>

<?php } } ?> 