<?php 
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING)); 
session_start();

// echo "<pre>";
// print_r($_SESSION['keranjang']);
// echo "</pre>";

include 'admin/inc/koneksi.php';
include 'admin/inc/tanggal.php';
include 'terbilang.php'; 
?> 

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Invoice</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="scss/bootstrap.css">
  
</head>
<body>

    <?php 
    $ambil=$con->query("SELECT * FROM pesan JOIN pelanggan ON pesan.id_pelanggan=pelanggan.id_pelanggan WHERE pesan.id_pesan='$_GET[id_pesan]' "); 
    $detail = $ambil->fetch_assoc();
    $tgl = tgl_indo($detail['tgl_pesan']); ?> 
    <?php 
    $idpelangganyangbeli = $detail["id_pelanggan"];
    $idpelangganyanglogin = $_SESSION["pelanggan"]["id_pelanggan"]; 
    ?>
  
    <div class="container mt-3">
        <div class="row justify-content-center">
            <div class="col-8">
                <div class="card">
                    <div class="card-body">
                        <h3 class="text-center font-weight-bold mb-0"><?php echo $judul ?></h3>
                        <p class="text-center font-weight-bold mb-0"><?php echo $alamat ?></p>
                        <p class="text-center font-weight-bold"><small class="font-weight-bold">Telepon No : <?php echo $telp ?> </small></p>
                        <div class="row pb-2 p-2">
                            <div class="col-md-6">
                             <p class="mb-0"><strong>Nomor Nota</strong>: <?php echo $detail['id_pesan'] ?></p>
                             <p><strong>Name</strong>: <?php echo $detail['nama_pelanggan'] ?></p>                      
                            </div>

                            <div class="col-md-6 text-right">
                             <p class="mb-0"><strong>Invoice Date</strong>: <?php echo $tgl ?></p>
                             <p><strong>Phone / Email</strong>: <?php echo $detail['nohp_pelanggan'] ?> / <?php echo $detail['email_pelanggan'] ?></p>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-bordered mb-0">
                                <thead>
                                    <tr>
                                        <th class="text-uppercase small font-weight-bold">No.</th>
                                        <th class="text-uppercase small font-weight-bold">Menu</th>
                                        <th class="text-uppercase small font-weight-bold text-right">Harga</th>
                                        <th class="text-uppercase small font-weight-bold text-center">Jumlah</th>
                                        <th class="text-uppercase small font-weight-bold text-right">S.Total</th> 
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $nomor=1; ?>
                                    <?php $ambil=$con->query("SELECT * FROM pesan_detail NATURAL JOIN menu WHERE id_pesan='$_GET[id_pesan]'");?>
                                    <?php while($pecah=$ambil->fetch_assoc()){ 
                                    $bilang = terbilang($detail['total_pesan']); ?> 
                                        <tr>
                                            <td><?php echo $nomor; ?></td>
                                            <td><?php echo $pecah['nama_menu']; ?></td>
                                            <td class="text-right"><?php echo number_format($pecah['harga'], 0, ',','.') ?></td>
                                            <td class="text-center"><?php echo $pecah['jumlah']; ?> /Porsi</td>
                                            <td class="text-right"><?php echo number_format($pecah['subharga'], 0, ',','.') ?>,-</td>
                                        </tr>
                                    <?php $nomor++; ?>
                                    <?php 
                                    $total1   = $pecah["subharga"]+$total1;
                                    } ?>
                                </tbody>
                                <tfoot class="font-weight-bold small">
                                    <tr>
                                        <td colspan="4">Total Bayar</td>
                                        <td class="text-right">Rp. <?php echo number_format($detail['total_pesan'], 0, ',','.') ?>,-</td> 
                                    </tr>
                                    <tr>
                                        <td colspan="8">Terbilang 
                                        <span class="float-right"><?php echo $bilang ?> Rupiah</span>
                                        </td> 
                                    </tr> 
                                </tfoot>
                            </table>
                        </div><!--table responsive end-->

                        <?php if ($detail['sts_pesan']=="Pending"): ?>
                        <span class="badge badge-warning">Status Pesanan : <?php echo $detail['sts_pesan'] ?></span> 
                        <?php endif ?>

                        <?php if ($detail['sts_pesan']=="Selesai"): ?>
                        <span class="badge badge-success">Status Pesanan : <?php echo $detail['sts_pesan'] ?></span> 
                        <?php endif ?>

                        <?php if ($detail['sts_pesan']=="Sudah Kirim Pembayaran"): ?>
                        <span class="badge badge-success">Status Pesanan : <?php echo $detail['sts_pesan'] ?></span> 
                        <?php endif ?>
                        
                        <span class="badge badge-primary">
                            <a href="javascript:window.print()" class="text-white"> Cetak</a>
                        </span> 

                        
                    </div>
                </div>
            </div>
        </div>
     
    </div>

</body>
</html>