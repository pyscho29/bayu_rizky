<?php 
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
session_start();
//koneksi database
include 'admin/inc/koneksi.php';
include 'terbilang.php';

if (empty($_SESSION["pelanggan"]) OR !isset($_SESSION["pelanggan"])) 
{
    echo "<script>alert('Silahkan login dulu.');</script>";
    echo "<script>location='login.php';</script>";
    exit();
}

$id_pesan = $_GET['id_pesan'];
$id_menu = $_GET['id_menu'];
$jumlahproduk = $_GET['jumlah'];
$ambil = $con->query("SELECT * FROM pesan WHERE id_pesan='$id_pesan'");
$detpembelian = $ambil->fetch_assoc();
$bilang = terbilang($detpembelian['total_pesan']);


$id_pelanggan_beli = $detpembelian["id_pelanggan"];
$id_pelanggan_login = $_SESSION['pelanggan']["id_pelanggan"];
if ($id_pelanggan_login !==$id_pelanggan_beli) 
{
  echo "<script>alert('Transaksi ini bukan punya anda.');</script>";
    echo "<script>location='riwayat.php';</script>";
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title><?php echo $judul ?></title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="admin/assets/<?php echo $logo ?>" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="scss/css2.css" rel="stylesheet"> 

    <!-- Font Awesome -->
    <link href="scss/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Topbar Start -->
    <div class="container-fluid">
        <div class="row bg-secondary py-2 px-xl-5">
            <div class="col-lg-6 d-none d-lg-block">
                <div class="d-inline-flex align-items-center">
                    <a class="text-dark" href=""><?php echo $judul ?></a>
                </div>
            </div>
            <div class="col-lg-6 text-center text-lg-right">
                <div class="d-inline-flex align-items-center"> 
                    <a class="text-dark px-2" href="">
                        (<small><?php echo $email ?></small>)
                    </a> |
                    <a class="text-dark px-2" href="">
                        (<small><?php echo $telp ?></small>)
                    </a> 
                </div>
            </div>
        </div>
        <div class="row align-items-center py-3 px-xl-5">
            <div class="col-lg-3 d-none d-lg-block">
                <a href="" class="text-decoration-none">
                    <h1 class="m-0 display-5 font-weight-semi-bold"><span class="text-warning font-weight-bold border px-3 mr-1">E</span><?php echo $singkatan ?></h1>
                </a>
            </div>
            <div class="col-lg-6 col-6 text-left">
                <form action="cari.php" method="GET">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Cari Menu Disini..." name="key">
                        <div class="input-group-append">
                            <input type="submit" name="open" value="Cari Menu" class="btn btn-secondary btn-sm">   
                        </div>
                    </div>
                </form> 
            </div>
            <div class="col-lg-3 col-6 text-right">
                <?php if (isset($_SESSION["pelanggan"])): ?>
                <a href="logout.php" class="btn border"> 
                    <span class="badge">Logout</span>
                </a> 
                <?php else: ?>
                <a href="login.php" class="btn border"> 
                    <span class="badge">Login</span>
                </a>
                <a href="" class="btn border"> 
                    <span class="badge">Daftar</span>
                </a> 
                <?php endif ?>
            </div>
        </div>
    </div>
    <!-- Topbar End -->


    <!-- Navbar Start -->
     <div class="container-fluid">
        <div class="row border-top px-xl-5">
            <?php include "kat.php" ?>
            <div class="col-lg-9">
                <?php include "menu.php" ?>
            </div>
        </div>
    </div>
    <!-- Navbar End -->   

    <div class="container-fluid bg-secondary mb-5">
        <div class="d-flex flex-column align-items-center justify-content-center" style="min-height: 300px">
            <h1 class="font-weight-semi-bold text-uppercase mb-3">Pembayaran</h1>
            <div class="d-inline-flex">
                <p class="m-0"><a href="index.php">Home</a></p>
                <p class="m-0 px-2">-</p>
                <p class="m-0">Pembayaran</p>
            </div>
        </div>
    </div>


    <!-- Shop Detail Start -->
    <!-- Checkout Start -->
    <div class="container-fluid pt-5">
        <div class="row px-xl-5"> 
            <div class="col-lg-6">
                <div class="card border-secondary mb-5">
                    <div class="card-header bg-secondary border-0">
                        <h4 class="font-weight-semi-bold m-0">Pembayaran</h4>
                    </div>
                    <div class="card-body"> 
                        <div class="d-flex justify-content-between">
                            <table class="table">
                                <thead></thead>
                                <tbody></tbody> 
                                <hr class="mt-0"> 
                                <tfoot>
                                    <th class="bg-secondary text-center text-sm" style="vertical-align: middle; font-size: 12px;">Total Bayar</th>
                                    <th class="text-right" style="font-size: 12px">
                                        Rp. <?php echo number_format($detpembelian['total_pesan'], 0, ',','.') ?> <br>
                                        <?php echo $bilang ?> Rupiah    
                                    </th>
                                </tfoot>
                            </table> 
                        </div>  
                    </div>                     
                </div>
            </div>
            <div class="col-lg-6">
                <div class="mb-4">
                    <div class="card-header bg-secondary border-0">
                        <h4 class="font-weight-semi-bold m-0">Pembayaran</h4>
                    </div> <br>
                    <form action="#" method="POST" class="billing-form" enctype="multipart/form-data"> 
                        <div class="row">
                            <div class="col-md-6 form-group">
                                <label>Nama</label>
                                <input class="form-control" type="text" name="penyetor" value="<?php echo $_SESSION['pelanggan']['nama_pelanggan'] ?>" readonly required>
                            </div>
                            <div class="col-md-6 form-group">
                                <label>Bank</label>
                                <select name="bank" class="form-control" required>
                                    <option>Pilih Bank</option>
                                    <option value="BCA">BCA</option>
                                    <option value="BNI">BNI</option>
                                    <option value="BRI">BRI</option>
                                    <option value="Mandiri">Mandiri</option>
                                    <option value="Bank Kalsel">Bank Kalsel</option>
                                    <option value="Bank Syariah Indonesia">Bank Syariah Indonesia</option> 
                                </select> 
                            </div>
                            <div class="col-md-6 form-group">
                                <label>Jumlah</label>
                                <input class="form-control" type="text" id="jml" name="jml" min="<?php echo $detpembelian['total_pesan'] ?>" max="<?php echo $detpembelian['total_pesan'] ?>" onkeypress="return angka(event);" required>
                            </div>
                            <div class="col-md-6 form-group">
                                <label>Bukti Transfer</label>
                                <input class="form-control" type="file" name="bukti" required>
                            </div> 
                            <div class="col-md-12 form-group">
                                <button class="btn btn-primary" name="checkout">Upload Bukti Transfer</button>
                            </div> 
                        </div>
                    </form>
                    <?php 
                    if (isset($_POST['checkout']))
                    {
                        $namabukti = $_FILES["bukti"]["name"];
                        $lokasibukti = $_FILES["bukti"]["tmp_name"];
                        $bukti = date("YmdHis").$namabukti;
                        move_uploaded_file($lokasibukti, "scss/bukti_bayar/$bukti");

                        $penyetor    = $_POST['penyetor'];
                        $bank    = $_POST['bank'];
                        $jml1         = $_POST['jml'];
                        $jml          = str_replace(".", "", $jml1);
                        $tgl = date("Y-m-d");

                        $con->query("INSERT INTO bayar (id_pesan,penyetor,bank,jml,tgl,bukti) VALUES ('$id_pesan','$penyetor','$bank','$jml','$tgl','$bukti') ");

                        $con->query("UPDATE pesan SET sts_pesan='Sudah Kirim Pembayaran' WHERE id_pesan='$id_pesan' ");


                        echo "<script>alert('Terimakasih Sudah Mengirimkan Bukti Pembayaran.');</script>";
                        echo "<script>location='riwayat.php';</script>";
                    }
                    ?> 
                </div>
            </div>
        </div>
    </div>
    <!-- Checkout End -->
    <!-- Shop Detail End -->  


    <!-- Footer Start -->
    <?php include "footer.php" ?>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="scss/jquery-3.4.1.min.js"></script>
    <script src="scss/bootstrap.bundle.min.js"></script>
    <script src="scss/all.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script> 

    <script type="text/javascript">

        function angka(evt) 
        {
            var charCode = (evt.which) ? evt.which : event.keyCode
            if (charCode > 31 && (charCode < 48 || charCode > 57)) 
            {
                return false;
            }
            return true;
        }

        var jml = document.getElementById('jml');
        jml.addEventListener('keyup', function(e)
        {
            jml.value = formatRupiah(this.value);
        });   
        
        /* Fungsi */
        function formatRupiah(angka, prefix)
        {
            var number_string = angka.replace(/[^,\d]/g, '').toString(),
                split    = number_string.split(','),
                sisa     = split[0].length % 3,
                rupiah     = split[0].substr(0, sisa),
                ribuan     = split[0].substr(sisa).match(/\d{3}/gi);
                
            if (ribuan) {
                separator = sisa ? '.' : '';
                rupiah += separator + ribuan.join('.');
            }
            
            rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
            return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
        } 

    </script> 
</body>

</html>