-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 30, 2024 at 01:24 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_catering`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL,
  `id_karyawan` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL,
  `level` varchar(20) NOT NULL,
  `status` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `id_karyawan`, `username`, `password`, `level`, `status`) VALUES
(6, 1, 'admin', 'admin', 'Admin', 'Aktif');

-- --------------------------------------------------------

--
-- Table structure for table `bayar`
--

CREATE TABLE `bayar` (
  `id_bayar` int(11) NOT NULL,
  `id_pesan` int(11) NOT NULL,
  `penyetor` varchar(255) NOT NULL,
  `bank` varchar(100) NOT NULL,
  `jml` int(11) NOT NULL,
  `tgl` date NOT NULL,
  `bukti` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bayar`
--

INSERT INTO `bayar` (`id_bayar`, `id_pesan`, `penyetor`, `bank`, `jml`, `tgl`, `bukti`) VALUES
(1, 1, 'Gunawan', 'BCA', 252500, '2024-01-21', '20240121202032icon.png'),
(2, 2, 'Gunawan', 'BNI', 166000, '2024-01-21', '20240121205113kalsel.png'),
(3, 3, 'Gunawan', 'Mandiri', 154000, '2024-01-30', '20240130095030pngwing.com.png'),
(4, 5, 'Hasanah', 'BCA', 300000, '2024-01-30', '20240130121100thread-9693776-16229870882396110170.png');

-- --------------------------------------------------------

--
-- Table structure for table `karyawan`
--

CREATE TABLE `karyawan` (
  `id_karyawan` int(11) NOT NULL,
  `nama_karyawan` varchar(100) NOT NULL,
  `tmp_lahir` varchar(100) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `nohp_karyawan` varchar(15) NOT NULL,
  `alamat_karyawan` varchar(255) NOT NULL,
  `ft_kar` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `karyawan`
--

INSERT INTO `karyawan` (`id_karyawan`, `nama_karyawan`, `tmp_lahir`, `tgl_lahir`, `nohp_karyawan`, `alamat_karyawan`, `ft_kar`) VALUES
(1, 'Administrator', 'Banjarmasin', '1993-12-20', '085246799359', 'Jl. Veteran', 'user2 (2).png'),
(2, 'Ahmad Husin', 'Banjarmasin', '1995-10-16', '087812230102', 'Jl. Kinibalu', 'user2 (2).png'),
(8, 'Hayatun Nufus', 'Banjarmasin', '2023-01-19', '08565282666', 'Jl. Banjarmasin', 'avatar-2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `id_kategori` int(11) NOT NULL,
  `kategori` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `kategori`) VALUES
(2, 'Gulai'),
(3, 'Nasi'),
(4, 'Mie');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `id_menu` int(11) NOT NULL,
  `menu` varchar(100) NOT NULL,
  `id_kategori` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `status_menu` varchar(15) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `foto_2` varchar(255) NOT NULL,
  `foto_3` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id_menu`, `menu`, `id_kategori`, `harga`, `status_menu`, `foto`, `foto_2`, `foto_3`) VALUES
(10, 'Nasi Samin', 3, 9000, 'Aktif', 'n samin.jpg', '', ''),
(11, 'Nasi Kuning', 3, 8300, 'Aktif', 'n kuning.jpg', '', ''),
(12, 'Gulai Ayam', 2, 11000, 'Aktif', 'g ayam.jpg', '', ''),
(13, 'Mie Telor', 4, 6500, 'Aktif', 'mietelor.jpg', '', ''),
(14, 'Gulai Kambing', 2, 15000, 'Aktif', 'g kambing.jpg', 'gulai-kambing.jpg', 'photo.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `meta`
--

CREATE TABLE `meta` (
  `id_meta` int(11) NOT NULL,
  `judul_meta` varchar(255) NOT NULL,
  `alamat_meta` varchar(255) NOT NULL,
  `email_meta` varchar(255) NOT NULL,
  `telp_meta` varchar(255) NOT NULL,
  `nama_pimpinan` varchar(255) NOT NULL,
  `logo_meta` varchar(255) NOT NULL,
  `singkatan` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `meta`
--

INSERT INTO `meta` (`id_meta`, `judul_meta`, `alamat_meta`, `email_meta`, `telp_meta`, `nama_pimpinan`, `logo_meta`, `singkatan`) VALUES
(1, 'Catering Rizky', 'Jl. Banjarmasin Kalimantan Selatan', 'catering@gmail.com', '082250502000', 'Rizki Madani', 'pngwing.com.png', 'CARIZ');

-- --------------------------------------------------------

--
-- Table structure for table `pelanggan`
--

CREATE TABLE `pelanggan` (
  `id_pelanggan` int(11) NOT NULL,
  `nama_pelanggan` varchar(100) NOT NULL,
  `nohp_pelanggan` varchar(15) NOT NULL,
  `email_pelanggan` varchar(150) NOT NULL,
  `alamat_pelanggan` varchar(255) NOT NULL,
  `username_pelanggan` varchar(100) NOT NULL,
  `password_pelanggan` varchar(50) NOT NULL,
  `status_pelanggan` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pelanggan`
--

INSERT INTO `pelanggan` (`id_pelanggan`, `nama_pelanggan`, `nohp_pelanggan`, `email_pelanggan`, `alamat_pelanggan`, `username_pelanggan`, `password_pelanggan`, `status_pelanggan`) VALUES
(1, 'Gunawan', '087867353778', 'gunawan@gmail.com', 'Jl. Keramat Raya', 'gunawan', 'gunawan', 'Aktif'),
(2, 'Hasanah', '089767823369', 'hasanah@gmail.com', 'Jl. Kuripan', 'sanah', 'sanah', 'Aktif');

-- --------------------------------------------------------

--
-- Table structure for table `pengeluaran`
--

CREATE TABLE `pengeluaran` (
  `id_pengeluaran` int(11) NOT NULL,
  `pln` int(11) NOT NULL,
  `pdam` int(11) NOT NULL,
  `gaji` int(11) NOT NULL,
  `jkotor` int(11) NOT NULL,
  `bulan` varchar(2) NOT NULL,
  `tahun` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pengeluaran`
--

INSERT INTO `pengeluaran` (`id_pengeluaran`, `pln`, `pdam`, `gaji`, `jkotor`, `bulan`, `tahun`) VALUES
(1, 120000, 200000, 0, 320000, '01', '2024');

-- --------------------------------------------------------

--
-- Table structure for table `pesan`
--

CREATE TABLE `pesan` (
  `id_pesan` int(11) NOT NULL,
  `id_pelanggan` int(11) NOT NULL,
  `tgl_pesan` date NOT NULL,
  `total_pesan` int(11) NOT NULL,
  `alamat_pesan` varchar(255) NOT NULL,
  `sts_pesan` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pesan`
--

INSERT INTO `pesan` (`id_pesan`, `id_pelanggan`, `tgl_pesan`, `total_pesan`, `alamat_pesan`, `sts_pesan`) VALUES
(1, 1, '2024-01-21', 252500, 'Jl. Keramat Raya Gg. Suaka Permai RT 05 RW 01 No 76', 'Selesai'),
(2, 1, '2024-01-21', 166000, 'Banjarmasin', 'Selesai'),
(3, 1, '2024-01-30', 154000, 'Jl. Keramat Gg Panda', 'Sudah Kirim Pembayaran'),
(4, 1, '2024-01-30', 8300, 'bjm', 'Pending'),
(5, 2, '2024-01-30', 300000, 'Jl. Kuripan', 'Sudah Kirim Pembayaran');

-- --------------------------------------------------------

--
-- Table structure for table `pesan_detail`
--

CREATE TABLE `pesan_detail` (
  `id_pesan_detail` int(11) NOT NULL,
  `id_pesan` int(11) NOT NULL,
  `id_menu` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `nama_menu` varchar(255) NOT NULL,
  `hmenu` int(11) NOT NULL,
  `subharga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pesan_detail`
--

INSERT INTO `pesan_detail` (`id_pesan_detail`, `id_pesan`, `id_menu`, `jumlah`, `nama_menu`, `hmenu`, `subharga`) VALUES
(1, 1, 12, 5, 'Gulai Ayam', 11000, 55000),
(2, 1, 13, 5, 'Mie Telor', 6500, 32500),
(3, 1, 14, 5, 'Gulai Kambing', 15000, 75000),
(4, 1, 10, 10, 'Nasi Samin', 9000, 90000),
(5, 2, 11, 20, 'Nasi Kuning', 8300, 166000),
(6, 3, 12, 14, 'Gulai Ayam', 11000, 154000),
(7, 4, 11, 1, 'Nasi Kuning', 8300, 8300),
(8, 5, 14, 20, 'Gulai Kambing', 15000, 300000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`),
  ADD KEY `id_karyawan` (`id_karyawan`);

--
-- Indexes for table `bayar`
--
ALTER TABLE `bayar`
  ADD PRIMARY KEY (`id_bayar`),
  ADD KEY `id_pesan` (`id_pesan`);

--
-- Indexes for table `karyawan`
--
ALTER TABLE `karyawan`
  ADD PRIMARY KEY (`id_karyawan`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id_menu`),
  ADD KEY `id_kategori` (`id_kategori`);

--
-- Indexes for table `meta`
--
ALTER TABLE `meta`
  ADD PRIMARY KEY (`id_meta`);

--
-- Indexes for table `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`id_pelanggan`);

--
-- Indexes for table `pengeluaran`
--
ALTER TABLE `pengeluaran`
  ADD PRIMARY KEY (`id_pengeluaran`);

--
-- Indexes for table `pesan`
--
ALTER TABLE `pesan`
  ADD PRIMARY KEY (`id_pesan`),
  ADD KEY `id_pelanggan` (`id_pelanggan`);

--
-- Indexes for table `pesan_detail`
--
ALTER TABLE `pesan_detail`
  ADD PRIMARY KEY (`id_pesan_detail`),
  ADD KEY `id_pesan` (`id_pesan`),
  ADD KEY `id_menu` (`id_menu`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `bayar`
--
ALTER TABLE `bayar`
  MODIFY `id_bayar` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `karyawan`
--
ALTER TABLE `karyawan`
  MODIFY `id_karyawan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id_kategori` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id_menu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `meta`
--
ALTER TABLE `meta`
  MODIFY `id_meta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `pelanggan`
--
ALTER TABLE `pelanggan`
  MODIFY `id_pelanggan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pengeluaran`
--
ALTER TABLE `pengeluaran`
  MODIFY `id_pengeluaran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `pesan`
--
ALTER TABLE `pesan`
  MODIFY `id_pesan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `pesan_detail`
--
ALTER TABLE `pesan_detail`
  MODIFY `id_pesan_detail` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
