<?php  
    error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
    session_start();
    include ("admin/inc/koneksi.php");
    include ("admin/inc/tanggal.php");    
?>  

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title><?php echo $judul ?></title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="admin/assets/<?php echo $logo ?>" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="scss/css2.css" rel="stylesheet"> 

    <!-- Font Awesome -->
    <link href="scss/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Topbar Start -->
    <div class="container-fluid">
        <div class="row bg-secondary py-2 px-xl-5">
            <div class="col-lg-6 d-none d-lg-block">
                <div class="d-inline-flex align-items-center">
                    <a class="text-dark" href=""><?php echo $judul ?></a>
                </div>
            </div>
            <div class="col-lg-6 text-center text-lg-right">
                <div class="d-inline-flex align-items-center"> 
                    <a class="text-dark px-2" href="">
                        (<small><?php echo $email ?></small>)
                    </a> |
                    <a class="text-dark px-2" href="">
                        (<small><?php echo $telp ?></small>)
                    </a> 
                </div>
            </div>
        </div> 
    </div>
    <!-- Topbar End -->   


    <!-- Products Start -->
    <div class="container-fluid pt-5"> <br>
        <div class="text-center mb-4">
            <h2 class="section-title px-5"><span class="px-2">Selamat Datang</span></h2> <br>
            <h4>Silahkan login untuk melanjutkan transaksi</h4>
        </div>
        <div class="row px-xl-5 pb-3"> 
            <div class="col-lg-4 pb-1"></div>
            <div class="col-lg-4 pb-1">
                <div class="card-body">

                    <?php  
                    if (isset($_POST['login'])) 
                    {
                        $username_pelanggan = $_POST['username_pelanggan'];
                        $password_pelanggan = $_POST['password_pelanggan']; 
                        $ambil = $con->query("SELECT * FROM pelanggan WHERE username_pelanggan='$username_pelanggan' AND password_pelanggan='$password_pelanggan' AND status_pelanggan='Aktif'"); 
                        $akunyangcocok = $ambil->num_rows; 
                        if ($akunyangcocok==1) 
                        {
                            $akun = $ambil->fetch_assoc();
                            $_SESSION["pelanggan"] = $akun;
                            echo "<script>alert('Anda berhasil login');</script>";
                            if (isset($_SESSION['keranjang']) OR !empty($_SESSION['keranjang']))
                            { echo "<script>location='checkout.php';</script>"; }
                            else
                            { echo "<script>location='index.php';</script>"; }
                        }
                        else
                        {
                            echo "<script>alert('Anda gagal login, periksa akun anda');</script>";
                            echo "<script>location='login.php';</script>";
                        }
                    }
                    ?>  
                    <form class="form-horizontal needs-validation" novalidate method="post">

                        <div class="mb-3">
                            <label class="form-label">Username</label>
                            <input type="text" class="form-control" name="username_pelanggan" autofocus required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Password</label>
                            <input type="password" class="form-control" name="password_pelanggan" id="upass" required>
                        </div>  <hr>

                        <div class="mt-3">
                            <button name="login" class="btn btn-primary w-100 waves-effect waves-light">L O G I N</button> 
                        </div> 

                    </form>
                </div>
            </div> 
            <div class="col-lg-4 pb-1"></div>
        </div>
    </div>
    <!-- Products End -->   


    <!-- Footer Start -->
    <?php include "footer.php" ?>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="scss/jquery-3.4.1.min.js"></script>
    <script src="scss/bootstrap.bundle.min.js"></script>
    <script src="scss/all.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script> 
</body>

</html>